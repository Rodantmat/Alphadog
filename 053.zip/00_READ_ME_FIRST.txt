============================================================
DOCUMENTATION UPDATE 053/054 — BASELINE V5 STATEFUL DELTA, CLASSIFICATION, BASELINE STATE, TARGETED RESCUE FINAL LOCK
Date: 2026-07-05 PT
Status: FINAL DEEP SCRUTINY PASS / LOCKED TO MOVE FORWARD

READ THIS FIRST — THIS SUPERSEDES UPDATE 052/053 WHERE THE V5 CLASSIFICATION RESCUE WAS STILL PARTIAL.
The 052 docs said: do not run Baseline Base; classification rescue incomplete. That is now stale. The final verified state after the July 5 work is:
- Incremental Morning Full Run completed PASS.
- Baseline V5 state hydrate anchor completed PASS.
- Baseline V5 stateful delta completed PASS and advanced authoritative state batch watermark to 2026-07-04.
- Baseline V5 targeted state reliability rescue v0.1.81 completed PASS.
- HP state rows: 67,040.
- Classification state rows: 67,040.
- HP/classification state parity: clean.
- Reliability blockers after rescue: 0.
- Counter defects: 0.
- MORE/LESS pair defects: 0.
- Context contamination: 0.
- Active/problem jobs after final scrutiny: 0.

New dedicated update files added in this package:
- 00_DOCUMENTATION_UPDATE_053_BASELINE_V5_STATEFUL_DELTA_RESCUE_FINAL_LOCK.txt
- 00_DOCUMENTATION_UPDATE_053_UPDATED_DOCS_LIST.txt
- 00_PACKAGE_MANIFEST_UPDATE_053_054.txt
- 129_BASELINE_V5_STATEFUL_DELTA_RESCUE_FINAL_LOCK_CURRENT.txt
- 130_TESTING_PROTOCOL_BASELINE_V5_STATEFUL_DELTA_RESCUE_LOCK.txt
- 131_NEW_CHAT_HANDOFF_BASELINE_V5_STATEFUL_DELTA_RESCUE_LOCKED.txt
- 132_DATABASE_REGISTRY_BASELINE_V5_STATE_CURRENT_AND_BATCHES.txt
- 133_RESCUE_BUTTON_SCOPE_AND_SAFETY_CONTRACT.txt
============================================================



============================================================
131_NEW_CHAT_HANDOFF_BASELINE_V5_STATEFUL_DELTA_RESCUE_LOCKED
Date: 2026-07-05 PT
Status: USE THIS HANDOFF FIRST IN THE NEXT CHAT
============================================================

READ THIS FIRST

The Baseline V5 classification/base/stateful delta/rescue phase is now locked after final deep scrutiny. Older docs saying Baseline V5 Classification Rescue is partial are stale. Do not continue from the old partial-rescue assumption.

The correct current state is:
- Incremental Morning Full Run completed PASS.
- V5 state hydrate anchor completed PASS.
- V5 stateful delta completed PASS.
- V5 targeted state reliability rescue completed PASS.
- V5 state authoritative watermark is 2026-07-04.
- HP state rows = 67,040.
- Classification state rows = 67,040.
- HP/classification parity = clean.
- Reliability blockers = 0.
- MORE/LESS pair defects = 0.
- No current/history production mutation occurred.
- Do not rerun the completed delta.
- Do not recalc baseline base.
- Do not rewrite HP math.

------------------------------------------------------------
1. CURRENT FINAL REQUESTS / BATCHES
------------------------------------------------------------

Parent full run:
- request_id: incremental_morning_full_run_mr86e6n4_1lq8wv.
- job_key: incremental-morning-full-run.
- worker: alphadog-v2-orchestrator.
- orchestrator version: alphadog-v2-orchestrator-v0.2.340-stateful-baseline-v5-delta-chunked-continuation.
- status: completed.
- tick_count: 18.
- created_at: 2026-07-05 19:20:02.
- started_at: 2026-07-05 19:20:03.
- finished_at: 2026-07-05 20:28:43.
- certification: INCREMENTAL_MORNING_FULL_RUN_CERTIFIED_CALENDAR_TALLY_BASE_DELTAS_EXPANSION_MINING_CLASSIFICATION_AND_BASELINE_DELTA_PASS.
- grade: FULL_RUN_PASS.

State hydrate/rehydrate:
- request_id: baseline_v5_stateful_delta_mr86qlha_48ldxp_rehydrate.
- batch_id: baseline_v5_state_rehydrate_batch_mr86qtut_lz2eqj.
- mode: baseline_v5_state_hydrate.
- certification: BASELINE_V5_STATE_HYDRATE_CERTIFIED_FULL_RERUN_EQUIVALENCE_ANCHOR.
- grade: PASS.
- watermark: 2026-06-29.
- rows: HP 67,040; classification 67,040.
- current/history mutated: 0.

Stateful delta:
- request_id: baseline_v5_stateful_delta_mr86qlha_48ldxp.
- batch_id: baseline_v5_stateful_delta_batch_mr86qpyw_0qgpao.
- worker version: alphadog-v2-phase3a-first-inning-pitcher-context-v0.1.79-baseline-v5-stateful-delta-audit-like-safe.
- mode: baseline_v5_stateful_delta.
- status/certification: BASELINE_V5_STATEFUL_DELTA_SHADOW_CERTIFIED_SAFE_CUTOFF_STATE_UPDATED_CHUNKED.
- grade: PASS.
- authoritative source_watermark_date: 2026-07-04.
- source_watermark_game_pk: 825108.0.
- current/history mutated: 0.
- full cumulative history recompute: 0.

Targeted V5 state rescue:
- request_id: baseline_v5_base_rescue_mr8e5d13_9ji08y.
- worker version: alphadog-v2-phase3a-first-inning-pitcher-context-v0.1.81-baseline-v5-base-rescue-state-target-wired.
- mode: baseline_v5_base_rescue.
- output batch_id: baseline_v5_state_current_target.
- certification: BASELINE_V5_BASE_RESCUE_CERTIFIED_V5_STATE_TARGETED_RELIABILITY_REPAIR_PASS.
- grade: TARGETED_STATE_RESCUE_PASS.
- targeted_state_reliability_rescue: 1.
- production_current_tables_mutated: 0.
- history_tables_mutated: 0.
- full_recalculation: 0.

------------------------------------------------------------
2. WHAT WAS FIXED
------------------------------------------------------------

The issue was not source mining or broad HP formula failure. The final proven defect was reliability metadata:
- Pitcher sample profiles were too aggressive.
- Pitcher rows with sample <20 had confidence above the desired safe cap.
- Pitcher rows with only 15-19 games were being labeled ELITE under the old profile wording.

Before rescue:
- HP pitcher small-sample confidence blockers: 17,250.
- HP pitcher small-sample enriched confidence blockers: 17,250.
- HP pitcher bad ELITE profile blockers: 12,320.
- Classification pitcher small-sample confidence blockers: 17,250.
- Classification pitcher bad ELITE profile blockers: 12,320.

After v0.1.81 rescue:
- All of the above blockers are 0.

The fix was targeted only to V5 state reliability metadata:
- player_baseline_v5_hp_state_current.
- player_baseline_v5_classification_state_current.

It preserved:
- baseline_hp_0_100.
- raw_rate_0_100.
- hit_count.
- miss_count.
- push_count.
- non_push_sample.
- line values.
- sides.
- state batch IDs.
- last processed dates.
- event ledger.
- authoritative watermark.

------------------------------------------------------------
3. FINAL PROFILE RULES
------------------------------------------------------------

Profile mapping:
- sample <5: TINY_SAMPLE.
- sample 5-14: LOW_SAMPLE.
- sample 15-29: MEDIUM_SAMPLE.
- sample 30-49: ESTABLISHED_SAMPLE.
- sample >=50: ELITE_SAMPLE.

Pitcher confidence cap:
- if player_type='pitcher' and sample<20, max confidence is 35.

For HP state sample = non_push_sample.
For classification state sample = games_sample.

------------------------------------------------------------
4. FINAL VALIDATION
------------------------------------------------------------

HP state shape:
- rows: 67,040.
- distinct state keys: 67,040.
- typed players: 529.
- props: 21.
- line values: 41.
- sides: 2.
- min last processed: 2026-06-29.
- max last processed: 2026-07-04.

Classification state shape:
- rows: 67,040.
- distinct state keys: 67,040.
- typed players: 529.
- props: 21.
- line values: 41.
- sides: 2.
- min last processed: 2026-06-29.
- max last processed: 2026-07-04.

Parity:
- HP missing classification: 0.
- Classification missing HP: 0.

Safety:
- bad HP rows: 0.
- bad confidence rows: 0.
- bad counters: 0.
- bad context rows: 0.
- bad cutoff rows: 0.
- MORE/LESS pair defects: 0.

Full-run active/problem jobs:
- 0.

Only non-completed row in full-run window:
- calendar_tally_precheck_mr86e851_04ik4j.
- status: failed.
- certification: INCREMENTAL_FULL_RUN_STALE_DELTA_CERTIFIER_REPLACED_BY_RETRY.
- grade: RETRY_REPLACED.
- This is not a blocker.

------------------------------------------------------------
5. CALIBRATION CONCLUSION
------------------------------------------------------------

Do not rewrite HP formula from current evidence.

Why:
- Overall bucket calibration was acceptable.
- Side-separated calibration had only one small monotonic violation: pitcher LESS bucket 50-60 dipped by -0.73.
- Broad HP cap tests worsened Brier overall and by sample band.
- Pitcher-specific caps helped some ER/RA pockets but worsened or did not help other pitcher props.

The repaired issue was reliability/trust labeling, not the HP number itself.

Future calibration monitoring should watch:
- pitcher_fantasy_score MORE.
- pitcher_outs high/medium lines.
- earned_runs LESS/MORE.
- runs_allowed LESS/MORE.
- hitter_strikeouts 0.5.

But these are not current blockers.

------------------------------------------------------------
6. NEXT DELTA RULE
------------------------------------------------------------

The next Baseline V5 stateful delta must start from:
- source_watermark_date > 2026-07-04.

Use authoritative table:
- SCORE_DB.player_baseline_v5_state_batches.

Do not trust stale output_json watermark:
- baseline_v5_stateful_delta_mr86qlha_48ldxp output_json still says 2026-06-29.
- This is a reporting bug only.
- Authoritative state batch row says 2026-07-04.

Final source-after-watermark checks:
- hitter_game_logs after 2026-07-04: 0.
- starter_history after 2026-07-04: 0.

------------------------------------------------------------
7. DO NOT DO
------------------------------------------------------------

Do not:
- rerun the completed 2026-06-30 through 2026-07-04 stateful delta;
- delete state rows;
- run full baseline base recalculation;
- rewrite HP formula;
- apply broad HP caps;
- use daily/weather/market/board/scoring context in Baseline V5 state;
- mutate source logs;
- treat v0.1.80 as working final rescue;
- treat the retry-replaced stale certifier as active failure;
- rely on stale output_json watermark for next delta.

------------------------------------------------------------
8. MOVE FORWARD
------------------------------------------------------------

The next chat should proceed from certified Baseline V5 state watermark 2026-07-04.
The state is locked.

============================================================
DOCUMENTATION UPDATE 052/053 — BASELINE V5 CLASSIFICATION RESCUE + NEW SCORING/BASELINE/BOARD/FULL-RUN STATE
Date: 2026-07-01
This document was prepended by the deep documentation update. The complete dedicated update files are:
- 00_DOCUMENTATION_UPDATE_052_DEEP_NEW_SCORING_BASELINE_BOARD_FULL_RUN_STATE.txt
- 119_SCORING_SYSTEM_V2_ARCHITECTURE_CURRENT.txt
- 120_BASELINE_V2_PROFILES_TIERS_AND_PROP_LOGIC_CURRENT.txt
- 121_PROP_LINE_VARIATIONS_DIRECTIONS_AND_SOURCE_LINE_RULES_CURRENT.txt
- 122_SCORE_ENRICHMENT_HP_FINAL_BOARD_SEQUENCE_CURRENT.txt
- 123_FULL_RUN_CURRENT_SEQUENCE_AND_VALIDATION_STATE.txt
- 124_CURRENT_WARNINGS_CAVEATS_AND_RISK_REGISTER_SCORING_V2.txt
- 125_DATABASE_REGISTRY_DELTA_BASELINE_V5_CLASSIFICATION_RESCUE.txt
- 126_CONTROL_ROOM_ORCHESTRATOR_WORKER_PARITY_BASELINE_V5_RESCUE.txt
- 127_TESTING_PROTOCOL_BASELINE_V5_CLASSIFICATION_RESCUE.txt
- 128_NEW_CHAT_HANDOFF_BASELINE_V5_CLASSIFICATION_RESCUE_CURRENT.txt

LATEST PROVEN STATE: Baseline V5 Classification Rescue request baseline_v5_classification_rescue_mr2jmxkj_qiu762 is still PARTIAL_CONTINUE at latest pasted SQL. Hitter classification is clean at 25,740 rows. Pitcher classification is incomplete at latest proof: 68 pitchers / ~9,426 rows vs expected 295 pitchers / 41,300 rows. Do not run Baseline Base until certification BASELINE_V5_CLASSIFICATION_RESCUE_COMPLETED_UNIFIED_HITTER_PITCHER_PASS with grade PASS is proven by SQL.
============================================================


LATEST DOCUMENTATION UPDATE — 2026-06-25: Added 00_DOCUMENTATION_UPDATE_050_NEW_SCORING_BASELINE_BOARD_FULL_RUN_STATE.txt and dedicated current-state docs for V2/V3 shadow scoring, Baseline V2 profiles/tiers, prop-line variation rules, full-run sequence, validation protocol, and warnings/risk register. Latest proven scheduled daily full run daily_full_run_2026_06_25_0900_PT completed 3/3 with DAILY_FULL_RUN_CERTIFIED_WITH_WARNINGS on orchestrator v0.2.316. Latest market/scoring child market_scoring_full_run_mqtoynqk_dxxu2z completed 11/11 with MARKET_SCORING_FULL_RUN_CERTIFIED_V3_SHADOW_SCORING_CHAIN_COMPLETED. Latest V3 shadow final board batch v2_final_board_batch_final_board_v3_shadow_mqtpl1ea_u1umfe wrote 633 rows to SCORE_DB.v2_final_board_current. This is a review/shadow board, not proven live-play production. No code changes made by this documentation update.

LATEST DOCUMENTATION UPDATE — 2026-06-17: Added 00_DOCUMENTATION_UPDATE_047_DAILY_FULL_RUN_SCORE_ENRICHMENT_HP_V2_BASELINE_STATE.txt.
This update documents the latest proven Incremental Morning Full Run pass, Daily Full Run V2 chain, Player Baseline HP completion, Score Enrichment V1, HP V2, Final Score V1, Final Board V2, DAILY_DB bullpen/schedule storage provenance, and the remaining open issue that direct named bullpen/schedule usage inside Score Enrichment is not yet proven. No code changes made by this documentation update.

LATEST LOCK UPDATE — 2026-06-10: Market/Scoring Full Run completed end-to-end with HP before Final Board. Parent market_scoring_full_run_mq7elun3_bvyuav completed 9/9 stages on orchestrator alphadog-v2-orchestrator-v0.2.219-market-prop-backend-flag-forwarder. Scoring Engine batch scoring_engine_batch_mq7fbunp_d0wtdq, HP batch hit_probability_batch_mq7fibha_leu8na, HP board batch hp_board_batch_mq7fzoxm_7g7kau, Score Final Board batch score_final_board_batch_mq7g0j16_d35urb. Final Board current has 90 review rows, 0 low-HP leakage, 0 HP mismatch, 0 score mismatch. Status: PASS / LOCKED WITH REVIEW WARNINGS ACCEPTED. See 89_MARKET_SCORING_FULL_RUN_HP_FINAL_BOARD_COMPLETION.txt and 00_DOCUMENTATION_UPDATE_044_MARKET_SCORING_FULL_RUN_HP_FINAL_BOARD_LOCK.txt.

LATEST DOCUMENTATION UPDATE — 2026-06-05: Scoring Engine documentation update added. Exact final lock report values were not supplied in this chat, so unspecified worker/version/request/batch/count/table fields are marked not provided rather than guessed. Ranking / Final Candidate Board is next; Results / Calibration Tracker remains later. See 85_SCORING_ENGINE_COMPLETION.txt.
LATEST LOCK UPDATE — 2026-06-02: Prop Factor Matrix Builder / Matrix Certifier is PASS / LOCKED. See 84_PROP_FACTOR_MATRIX_BUILDER_COMPLETION.txt. Scoring Engine is next. RFI/NRFI remains deferred for separate future design.

============================================================
PROP FACTOR MINER / INTERNAL HITTER + PITCHER FACTOR PACKETS LOCK UPDATE — 2026-06-02

- Status: PASS / LOCKED WITH ACCEPTED CAVEATS.
- Phase: Internal Prop Factor Mining.
- Logical worker: alphadog-v2-prop-factor-miner.
- Deployed slot: alphadog-v2-phase2b-recent-form.
- Final fixed logical version: alphadog-v2-prop-factor-miner-v0.1.2-pitcher-readiness-availability-fix.
- Final deployed slot version: alphadog-v2-phase2b-recent-form-v0.2.2-pitcher-readiness-availability-fix.
- Control Room observed version during verification: alphadog-v2-control-room-v1.6.149-prop-factor-buttons.
- Job key: prop-factor-miner.
- Scope: internal-only prop-specific evidence assembler for standard hitter and pitcher prop factor packets.
- It consumes certified prepared-board, daily context readiness, market context, reference, base/delta/splits/metrics layers; it does not redo source prep.
- It does not make external calls, mine Odds API / Parlay API / Gemini / MLB API, score, rank, build matrix packets, write final board, mutate prepared board, mutate market evidence, or decide final recommendations.
- Output tables documented/verified in SCORE_DB: prop_factor_hitter_packets, prop_factor_pitcher_packets, prop_factor_coverage_current, prop_factor_issues, prop_factor_batches.
- Prepared-board input proof after refresh: 585 prepared rows read; safe prepared-board contract respected before mining: pickable_safe=1, matchup_status='calendar_matched', player_match_status='matched', official_game_pk present, official_game_time_utc present.
- Hitter final state: 382 hitter packets written, 0 blocked rows, 0 missing factor rows; only warning reason was lineup_context_missing_or_not_posted across 382 rows / 11 games / 167 players. This is expected before official lineups post and does not kill pickability by itself.
- Pitcher final run: prop_factor_pitcher_mpw9kbrq_1f2bnx; prepared_rows_read 585, eligible_rows 66, packets_written 66, blocked_rows 23, warning_rows 0, issue_rows 23, missing_factor_rows 0, certification PROP_FACTOR_PACKETS_CERTIFIED_WITH_WARNINGS, grade PASS_WITH_BLOCKED_ROWS.
- Supported pitcher packet counts: earned_runs 9, earned_runs_allowed 2, hits_allowed 10, pitcher_outs 20, pitcher_strikeouts 24, walks_allowed 1.
- Remaining pitcher-family blocked rows: 23 RFI/NRFI rows, reason PROP_DEFERRED_PENDING_SEPARATE_DESIGN. This is intentional, correct, and not a bug. RFI/NRFI requires separate future design.
- Root cause fixed: the initial miner falsely emitted pitcher_availability_context_missing even though Daily Context Readiness already had active_available / starter available / bullpen normal. v0.1.2 fixed readiness/availability interpretation for pitcher packets.
- Operational root cause fixed by rerun: Daily Context Readiness was stale versus refreshed board. Factor miner read 585 rows while old readiness covered 458 rows, producing 12 temporary daily_context_readiness_missing_for_current_prepared_row warnings. Rerunning Daily Context Certifier aligned current_rows_written to 585, then pitcher factor miner rerun cleared those warnings.
- Daily Context Certifier alignment proof: alphadog-v2-daily-certifier-v0.1.4-time-bound-not-applicable, request daily_context_certifier_mpw9jist_rpt5ky, batch daily_context_readiness_batch_mpw9jmvz_5htvvd, prepared_rows_read 585, current_rows_written 585, ready_with_warnings_count 66, ready_partial_enrichment_count 463, blocked_count 56, certification DAILY_CONTEXT_READINESS_CERTIFIED_ENRICHMENT_LEDGER_WRITTEN, grade PASS_WITH_HARD_BLOCKERS.
- Locked operational order after board refresh: Board Refresh -> Score Prep / Prepared Board -> Daily Context workers -> Daily Context Certifier -> Market Context -> Prop Factor Miner -> Matrix Builder. If prepared board changes after Daily Context Certifier runs, rerun Daily Context Certifier before Prop Factor Miner.
- Next phase: Prop Factor Matrix Builder / Matrix Certifier. Do not build scoring yet.
- See 83_PROP_FACTOR_MINER_COMPLETION.txt for full root cause, verification, SQL/debugging protocol, caveats, and next-step handoff.
============================================================

DAILY CONTEXT READINESS / ENRICHMENT CERTIFIER v0.1.3 LOCK UPDATE — 2026-05-29

- Status: PASS / LOCKED for started-slate behavior.
- Worker: alphadog-v2-daily-certifier.
- Worker version: alphadog-v2-daily-certifier-v0.1.3-started-not-applicable-fix.
- Job key: daily-certifier.
- Control Room: alphadog-v2-control-room-v1.6.136-daily-context-certifier-started-not-applicable.
- Visible button: DAILY JOBS > Context Cert.
- Locked request: daily_context_certifier_mpqblauw_tmkz00.
- Locked batch: daily_context_readiness_batch_mpqble82_xmmzy8.
- Certification: DAILY_CONTEXT_READINESS_CERTIFIED_ENRICHMENT_LEDGER_WRITTEN.
- Grade: PASS_WITH_NOT_APPLICABLE.
- Final proof: prepared_rows_read 1909, current_rows_written 1909, distinct prepared rows 1909, games 4, hard_blocker_count 0, blocked_count 0, not_applicable_count 1909, rows outside today/tomorrow 0, external_calls 0.
- Interpretation: the slate was already started/expired, so all rows were correctly marked not_applicable rather than hard-blocked. Started/expired rows are no longer fresh pickable opportunities, but that does not mean daily context is broken.
- Philosophy: Daily context enriches; it does not automatically enforce. Missing late context should usually be a warning, enrichment gap, waiting state, or not_applicable state, not a system failure.
- Output tables: DAILY_DB.daily_context_readiness_batches, DAILY_DB.daily_context_readiness_current, DAILY_DB.daily_context_readiness_issues.
- Retention: current/issues are volatile and retain today/tomorrow only; batches remain small audit metadata.
- Warnings/enrichment gaps are carried as non-blocking signals unless a true integrity/eligibility/source/schema failure exists or a future prop-specific design explicitly makes that context mandatory.
- Previous failed v0.1.2/v0.1.1 artifacts remain audit history only; current table reflects the latest v0.1.3 run.
- See 79_DAILY_CONTEXT_READINESS_CERTIFIER_COMPLETION.txt and 80_DAILY_CONTEXT_READINESS_CERTIFIER_TESTING_SQL.txt for full details.

============================================================

DAILY TEAM SCHEDULE SPOT / DAILY CONTEXT PHASE 6 LOCK UPDATE — 2026-05-29

- Status: PASS / LOCKED WITH WARNINGS ACCEPTED.
- Worker: alphadog-v2-daily-schedule-v0.1.6-self-verifying-retention-final.
- Job key: daily-team-schedule-spot.
- Visible Control Room button: DAILY JOBS > Team Spot.
- Locked request: daily_team_schedule_spot_mpq6eb7r_yelenn.
- Locked batch: daily_team_schedule_spot_batch_mpq6eeuj_65akmb.
- Certification: DAILY_TEAM_SCHEDULE_SPOT_CERTIFIED_WITH_WARNINGS / PASS_WITH_WARNINGS.
- Final proof: queue completed cleanly, data_ok=1, calendar_games_checked=21, prepared_games_checked=4, prepared_rows_read=1909, teams_checked=8, team_rows_written=8, snapshot_rows_written=8, source_failures=0, blocker_count=0, warning_count=25, high_risk_team_count=1, unknown_team_count=0.
- Current proof: 8 current rows for 4 prepared-board games / 8 team sides, all prepared-board relevant, no missing status/confidence/risk fields.
- Snapshot proof: 8 snapshot rows for locked batch.
- Retention proof: current/snapshots/issues all have 0 rows outside today/tomorrow.
- Timezone fix proof: Toronto -> Baltimore has timezone_transition_flag=0; prior/current offsets both -240; timezone_name_changed_flag remains audit-only in details_json and does not create a warning.
- Accepted warnings: four_in_six 8, played_yesterday 8, three_in_four 8, travel_required 1. These warnings are not blockers.
- Mutation safety: no board mutation, no SCORE_DB mutation, no scoring, no ranking, no final-board writes, no external calls, no calendar rebuild, and no duplication of other Daily Context phases.
- Root cause/fix history: v0.1.1 not locked because timezone-name changes were over-sensitive; v0.1.2 fixed UTC-offset logic but exposed stale issue cleanup; v0.1.3/v0.1.4 were not locked due volatile cleanup/helper issues; v0.1.6 is the self-verifying final that clears active rows before write, writes fresh rows, prunes only outside today/tomorrow after write, and verifies DB row counts.
- Daily Context roadmap: Phases 1-7 plus Daily Context Readiness / Enrichment Certifier v0.1.3 are locked. Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior. Daily Umpire Context / Daily Context Phase 7 is PASS / LOCKED.
- Daily Game Status remains owned by Calendar / Delta Certifier and is not a separate remaining Daily Context worker.
- See 76_DAILY_TEAM_SCHEDULE_SPOT_PHASE_6_COMPLETION.txt for full lock details.

============================================================

DAILY BULLPEN AVAILABILITY / DAILY CONTEXT PHASE 5 LOCK UPDATE — 2026-05-28

- Status: PASS / LOCKED WITH WARNINGS ACCEPTED.
- Worker: alphadog-v2-daily-bullpen-availability-v0.1.0-internal-bullpen-history-context.
- Locked batch: daily_bullpen_batch_mpq41p38_mp6knr.
- Locked request: daily_bullpen_availability_mpq41lbu_4hd911.
- Certification: DAILY_BULLPEN_CERTIFIED_WITH_WARNINGS / PASS_WITH_WARNINGS.
- Batch proof: calendar_games_checked 4, prepared_games_checked 4, prepared_rows_read 1909, teams_checked 8, team_rows_written 8, pitcher_rows_written 54, snapshot_rows_written 8, source_failures 0, blocker_count 0, warning_count 11, unknown_team_count 0.
- Retention proof: rows_outside_today_tomorrow = 0 for daily_bullpen_availability_current, daily_bullpen_pitcher_availability_current, daily_bullpen_availability_snapshots, and daily_bullpen_availability_issues.
- Prepared-game coverage proof: 4 prepared games, 8 prepared team sides, 1909 prepared rows, exactly 8 current team-side rows, no missing game/team/opponent IDs, no duplicate game/team rows.
- Pitcher/team linkage proof: 54 pitcher rows, missing_official_date 0, missing_team_id 0, missing_pitcher_id 0, missing_pitcher_name 0, missing_availability_status 0, detached_pitcher_rows 0.
- Snapshot proof: 8 snapshot rows, 4 games, 8 game/team sides, missing_game_pk 0, missing_team_id 0.
- Accepted warnings: back_to_back_relievers 2, bullpen_high_risk_two_day_load 4, bullpen_taxed_yesterday 1, high_usage_relievers 4. All 11 are explainable workload/fatigue warnings, not blockers.
- Output tables: DAILY_DB.daily_bullpen_availability_current, DAILY_DB.daily_bullpen_pitcher_availability_current, DAILY_DB.daily_bullpen_availability_snapshots, DAILY_DB.daily_bullpen_availability_issues, DAILY_DB.daily_bullpen_availability_batches.
- Volatile current/pitcher-current/snapshot/issue rows retain today/tomorrow only; daily_bullpen_availability_batches remains small audit metadata unless the user explicitly requests pruning.
- No external calls, no board mutation, no SCORE_DB mutation, no calendar mutation, no scoring, no ranking, no final-board writes.
- Daily Context roadmap now has Phases 1-7 plus Daily Context Readiness / Enrichment Certifier v0.1.3 locked; Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior. Daily Team Schedule Spot / Daily Context Phase 6 is PASS / LOCKED WITH WARNINGS ACCEPTED at alphadog-v2-daily-schedule-v0.1.6-self-verifying-retention-final.
- Daily Game Status remains owned by Calendar / Delta Certifier and is not a separate remaining Daily Context worker.
- See 75_DAILY_BULLPEN_AVAILABILITY_PHASE_5_COMPLETION.txt for full lock details.

============================================================

DAILY WEATHER / ROOF / PARK CONDITIONS / DAILY CONTEXT PHASE 4 LOCK UPDATE — 2026-05-28

- Status: PASS / LOCKED WITH WARNINGS ACCEPTED.
- Worker: alphadog-v2-daily-weather-v0.1.0-source-probe-and-schema.
- Locked batch: daily_game_weather_batch_mpq37jz5_efrhyb.
- Certification: DAILY_WEATHER_CERTIFIED_WITH_WARNINGS / PASS_WITH_WARNINGS.
- Current-state proof: current_rows 4, distinct_games 4, rows_outside_today_tomorrow 0, missing_weather_status 0, missing_roof_status 0, not_prepared_relevant_rows 0.
- Batch proof: prepared_games_checked 4, weather_rows_written 4, snapshot_rows_written 4, blocker_count 0, warning_count 3, roof_unknown_count 1, weather_unknown_count 0, external_calls 8.
- Accepted warnings: Fenway forecast_offset_window, Fenway rain_risk, Globe Life Field roof_unknown_retractable.
- Output tables: DAILY_DB.daily_game_weather_current, DAILY_DB.daily_game_weather_snapshots, DAILY_DB.daily_game_weather_batches, DAILY_DB.daily_game_weather_issues.
- Legacy seed tables DAILY_DB.daily_weather and DAILY_DB.daily_roof_status remain untouched and are not the v2 contract.
- Volatile current/snapshot/issue weather rows are retained for today/tomorrow only; batch rows may persist for audit.
- No board mutation, no SCORE_DB mutation, no calendar mutation, no scoring, no ranking, no final-board writes.
- Daily Context roadmap now has Phases 1-7 plus Daily Context Readiness / Enrichment Certifier v0.1.3 locked; Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior. Daily Team Schedule Spot / Daily Context Phase 6 is PASS / LOCKED WITH WARNINGS ACCEPTED at alphadog-v2-daily-schedule-v0.1.6-self-verifying-retention-final.
- See 74_DAILY_WEATHER_ROOF_PHASE_4_COMPLETION.txt for full lock details.

============================================================

DAILY PLAYER AVAILABILITY / DAILY CONTEXT PHASE 3 COMPLETION — 2026-05-28

STATUS SUMMARY:
- Daily Player Availability / Daily Context Phase 3: PASS / LOCKED.
- Locked worker/version: alphadog-v2-daily-player-availability-v0.1.3-today-tomorrow-retention-prune.
- Locked batch: daily_player_availability_batch_mpq22kaa_9bk72b.
- Certification: DAILY_PLAYER_AVAILABILITY_CERTIFIED_WITH_PLAYER_BLOCKERS.
- Certification grade: PASS_WITH_WARNINGS.
- Purpose: mines prepared-board-relevant MLB player availability/roster status anchored to official game_pk and MLB player/team identity.
- Role: Daily Context layer only. It is not scoring, ranking, final-board, weather, bullpen, umpire, team schedule spot, lineup, or starter logic.

ROOT CAUSE / FAILURE-AWARE HISTORY:
Daily Player Availability had to determine availability from official MLB roster and transaction signals rather than from a single Boolean "available tonight" field. Earlier versions exposed two important failure modes:
- v0.1.0 produced stale false IL blocker rows because the injured-list roster source was trusted too broadly.
- v0.1.1 still produced false IL blockers because the worker trusted the endpoint bucket instead of validating each roster row's actual status payload.
- v0.1.2 fixed the false IL blocker issue by accepting an injured-list hit only when the row itself proved IL status, and proved a clean current-state availability run.
- v0.1.3 added the required retention prune so current-state availability data does not grow indefinitely. The current table now stays latest-run plus today/tomorrow official dates only.

LOCKED FIX / FINAL BEHAVIOR:
- Reads prepared-board-relevant safe rows from SCORE_DB.score_board_prepared_current only.
- Anchors rows to official game_pk, official_date, official game time, MLB player ID, and MLB team ID.
- Uses official MLB roster/transaction context to distinguish active availability, recent transaction warnings, and official transaction blockers.
- Writes sidecar Daily Context availability tables only.
- Keeps current_v1 limited to latest run and today/tomorrow official dates.
- Prunes old current rows and prevents old-batch contamination of current_v1.
- Preserves older historical issue rows by batch for audit, but those rows do not contaminate current_v1.
- Does not mutate raw board tables, prepared board rows, scoring tables, ranking tables, or final-board candidate tables.

FINAL VERIFIED OUTCOME — LOCKED BATCH:
- batch_id: daily_player_availability_batch_mpq22kaa_9bk72b.
- worker_version: alphadog-v2-daily-player-availability-v0.1.3-today-tomorrow-retention-prune.
- current_rows = 88.
- unique_players = 88.
- unique_games = 4.
- unique_teams = 8.
- rows_from_old_batches = 0.
- rows_outside_today_tomorrow = 0.
- missing_game_pk = 0.
- missing_mlb_player_id = 0.
- missing_team_mlb_id = 0.
- missing_source_snapshot = 0.
- previous current rows pruned = 45.

FINAL AVAILABILITY DISTRIBUTION:
- 85 rows: active_available / active_roster / HIGH_OFFICIAL_ACTIVE_ROSTER.
- 2 rows: active_available / active_roster / WARNING_RECENT_TRANSACTION_ACTIVE.
- 1 row: optioned / not_active_roster / BLOCKED_OFFICIAL_TRANSACTION.

LATEST-BATCH ISSUES VERIFIED CORRECT:
- Warning: Nathan Lukes — SC Status Change, activated from 10-day IL; active roster confirms available.
- Warning: Taylor Trammell — SC Status Change, activated from 10-day IL; active roster confirms available.
- Blocker: Esmerlyn Valdez — OPT Optioned to Indianapolis Indians on 2026-05-28; active roster does not confirm availability.

RETENTION PROOF:
- Only official_date 2026-05-28 remained in current_v1 for the locked board snapshot.
- Current table had 0 rows from old batches.
- Current table had 0 rows outside today/tomorrow.
- Previous current rows pruned: 45.
- Conclusion: Daily Player Availability current-state retention works. current_v1 now stays latest-run plus today/tomorrow only.

TABLE / DB OWNERSHIP:
Daily Player Availability is a Daily Context layer. Confirmed sidecar table names:
- DAILY_DB.daily_player_availability_current_v1.
- DAILY_DB.daily_player_availability_snapshots_v1.
- DAILY_DB.daily_player_availability_batches_v1.
- DAILY_DB.daily_player_availability_issues_v1.
Legacy/stub table remains untouched:
- DAILY_DB.daily_player_availability.

The worker uses prepared-board relevance from:
- SCORE_DB.score_board_prepared_current, restricted to pickable_safe rows with calendar/player matches and official game anchors.

Prepared-board safe downstream contract remains:
SELECT *
FROM score_board_prepared_current
WHERE pickable_safe = 1
  AND matchup_status = 'calendar_matched'
  AND player_match_status = 'matched'
  AND official_game_pk IS NOT NULL
  AND official_game_time_utc IS NOT NULL;

Do not mine raw board tables directly:
- MARKET_DB.prizepicks_board_current.
- MARKET_DB.sleeper_board_current.

NO-MUTATION CONTRACT:
Daily Player Availability does not mutate:
- raw board tables.
- prepared board rows.
- scoring tables.
- ranking/final candidate tables.
- source/history base/delta tables.
- Calendar / Delta Certifier.
- Daily Starters.
- Daily Lineups.
- Board Full Run.
- Incremental Morning Full Run.

ARCHITECTURE RELATIONSHIPS:
- Calendar/Game Status is already covered by TEAM_DB.mlb_game_calendar, TEAM_DB.mlb_game_data_coverage, and Delta Certifier / calendar-tally. Do not create a separate Daily Game Status worker.
- Daily Starters / Daily Context Phase 1 is PASS / LOCKED and must not be duplicated.
- Daily Lineups / Daily Context Phase 2 is PASS / LOCKED and must not be duplicated.
- Daily Player Availability / Daily Context Phase 3 is PASS / LOCKED at v0.1.3.
- Daily Context Readiness / Enrichment Certifier v0.1.3 aggregates starters, lineups, player availability, weather/roof, bullpen availability, umpire context, and team schedule spot. Daily Player Availability is not that certifier.

DOCUMENTED CORRECTION:
A prior interpretation used worker output field issues_written instead of confirmed issue table schema. Future chats must not rely on worker summary fields alone when table-level proof is required. Use PRAGMA/schema-first SQL before selecting table columns. Final lock is based on verified table state and batch-scoped issue rows, not only worker output summary.

CAVEATS:
- Historical v0.1.0 and v0.1.1 false IL blocker rows can remain in daily_player_availability_issues_v1 by old batch ID. They are historical noise only and do not contaminate daily_player_availability_current_v1.
- Latest lock is table-proof based, not merely output-summary based.
- Daily Player Availability is not a scoring/ranking/final-board worker.
- Daily Player Availability is not the Daily Context Certifier.

DO NOT REOPEN:
Do not reopen or patch Daily Player Availability unless new SQL/source output proves a real issue. Do not duplicate Calendar/Game Status, Daily Starters, Daily Lineups, weather/roof, bullpen, umpire, team schedule spot, Score Prep, Board Full Run, Delta Certifier, or Incremental Morning Full Run. Do not mutate prepared board/scoring/ranking/final candidate tables.

DAILY CONTEXT ROADMAP UPDATE:
Locked:
1. Daily Starters / Daily Context Phase 1.
2. Daily Lineups / Daily Context Phase 2.
3. Daily Player Availability / Daily Context Phase 3.
4. Daily Weather / Roof / Park Conditions / Daily Context Phase 4, latest locked worker alphadog-v2-daily-weather-v0.1.0-source-probe-and-schema.

Locked:
5. Daily Bullpen Availability / Daily Context Phase 5, latest locked worker alphadog-v2-daily-bullpen-availability-v0.1.0-internal-bullpen-history-context.

Next active worker:
7. Daily Umpire Context Worker — PASS / LOCKED
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.

Locked immediately before it:
6. Daily Team Schedule Spot Worker — PASS / LOCKED WITH WARNINGS ACCEPTED.

Remaining future phases:
6. Daily Team Schedule Spot Worker — PASS / LOCKED WITH WARNINGS ACCEPTED.
7. Daily Umpire Context Worker — PASS / LOCKED
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.

Daily Game Status is not a separate remaining worker because Calendar / Delta Certifier already owns Calendar/Game Status.

AUTHORITATIVE COMPLETION DOC:
See 73_DAILY_PLAYER_AVAILABILITY_PHASE_3_COMPLETION.txt.

============================================================

DAILY LINEUPS / DAILY CONTEXT PHASE 2 COMPLETION — 2026-05-28

STATUS SUMMARY:
- Daily Lineups / Daily Context Phase 2: PASS / LOCKED.
- Locked worker/version: alphadog-v2-daily-lineups-v0.1.8-today-tomorrow-retention-prune.
- Phase name: Daily Lineups / Daily Context Phase 2.
- Final certification: PASS_LIVE_GATED_LINEUPS_WRITTEN.
- Final grade: LIVE_GATED_CONFIRMED_LINEUP_WRITES.
- Final verified batch: daily_lineups_batch_mpq0c8at_kgnjtp.
- Retention window: today_and_tomorrow.
- retention_dates_kept = ["2026-05-28","2026-05-29"].
- retention_prune_enabled = true.
- lineup_rows_pruned = 0 on final verification run because no outside-window rows existed.
- batch_rows_pruned = 0 on final verification run because no outside-window batch rows existed.
- rows_written = 63.
- writes_performed = 63.

ROOT CAUSE / ARCHITECTURE CLARIFICATION:
Daily Lineups had been on standby because actual MLB battingOrder arrays were not posted yet. Earlier source-probe/dry-run versions correctly proved source reachability, parser contract, and write guardrails, but production writes had to remain blocked until official battingOrder data existed. Once real posted battingOrder arrays appeared, v0.1.7 proved live-gated writes. v0.1.8 then locked the required today+tomorrow retention prune so Daily Lineups does not keep unnecessary current-state lineup data indefinitely.

LOCKED FIX / FINAL BEHAVIOR:
- Writes only official MLB posted battingOrder lineup sides.
- Does not invent lineups.
- Does not write projected/unposted lineups as posted_lineup.
- Does not write partial lineups.
- A side is valid only when it has 9 rows, 9 distinct lineup slots, 9 distinct players, and row status posted_lineup.
- Partial or unposted sides are skipped safely.
- Worker is live-gated: writes occur only after official battingOrder is posted and ID mapping passes.
- Retention prune is active and keeps only today + tomorrow current-lineup data.
- No rows outside today/tomorrow retention window should remain.

FINAL VERIFIED OUTCOME:
- Bad row query returned 0 rows.
- Every written team-side had exactly 9 rows.
- Every written side had 9 distinct slots.
- Every written side had 9 distinct players.
- Every row was posted_lineup.
- No rows existed outside the today/tomorrow retention window.
- daily_lineups_current final count: 63 rows, 4 games, 7 team-sides.
- Team-side rows written: 822896 away/home, 823378 away only, 824757 away/home, 824834 away/home.
- The missing 823378 home side was intentionally skipped because that side was unposted at run time; this is correct behavior, not a failure.

LOCKED DATA CONTRACT:
- Daily Lineups is a Daily Context layer.
- Writes to DAILY_DB daily lineup context tables.
- Confirmed tables from final PRAGMA/SQL verification:
  - DAILY_DB.daily_lineups_current
  - DAILY_DB.daily_lineups_batches
- DAILY_DB.daily_lineups_current includes: lineup_row_id, batch_id, game_pk, official_date, game_time_utc, team_side, team_id, team_name, player_id, player_name, lineup_slot, batting_order_code, bat_side, active_position, lineup_status, confidence_label, source_endpoint, source_mode, fetched_at_utc, created_at, updated_at.
- DAILY_DB.daily_lineups_batches includes: batch_id, job_key, worker_name, worker_version, mode, source_probe_lane, certification_status, certification_grade, write_gate_status, production_lineup_writes_enabled, derived_backup_write_enabled, games_checked, lineup_write_ready_games, rows_written, writes_performed, started_at, completed_at, output_json, created_at, updated_at.
- The worker also verified DAILY_DB.daily_player_availability_current exists, but Daily Lineups v0.1.8 keeps derived availability writes locked off. Player Availability remains its own next worker.
- Anchors to TEAM_DB.mlb_game_calendar.game_pk.
- May use prepared-board relevance from SCORE_DB.score_board_prepared_current pickable_safe rows when applicable.
- Future downstream workers should use prepared-board safe rows from SCORE_DB.score_board_prepared_current where pickable_safe = 1, matchup_status = 'calendar_matched', player_match_status = 'matched', official_game_pk IS NOT NULL, and official_game_time_utc IS NOT NULL.
- Do not mine raw board tables directly.

NO-MUTATION CONTRACT:
Daily Lineups does not mutate:
- raw board tables
- prepared board rows
- scoring tables
- ranking/final candidate tables
- source/history base/delta tables
- Incremental Morning Full Run
- Board Full Run
- Delta Certifier
- Score Prep

ARCHITECTURE RELATIONSHIPS:
- Calendar/Game Status is already covered by TEAM_DB.mlb_game_calendar, TEAM_DB.mlb_game_data_coverage, and the Delta Certifier/calendar-tally system. Do not create a separate Daily Game Status worker.
- Daily Starters / Daily Context Phase 1 is already locked and must not be duplicated by Daily Lineups.
- Daily Lineups / Daily Context Phase 2 is now locked at v0.1.8.
- Daily Player Availability / Daily Context Phase 3 is PASS / LOCKED. Daily Weather / Roof / Park Conditions, Daily Bullpen Availability, and Daily Team Schedule Spot are locked; Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior.
- Daily Context Readiness / Enrichment Certifier v0.1.3 aggregates starters, lineups, player availability, weather/roof, bullpen availability, umpire context, and team schedule spot. Daily Lineups is not that certifier.

CAVEATS:
- Partial/unposted sides are intentionally skipped safely. This is correct behavior, not a failure.
- Daily Lineups must never invent or write projected/unposted lineups as posted_lineup.
- Missing bat_side warnings are non-blocking for lineup identity/slot proof; batting order writes are anchored to official battingOrder and player ID mapping.
- Daily Lineups is not player availability, weather/roof, bullpen, umpire, team schedule spot, scoring, ranking, or final-board logic.

DAILY CONTEXT ROADMAP UPDATE:
Locked:
1. Daily Starters / Daily Context Phase 1.
2. Daily Lineups / Daily Context Phase 2, latest locked worker alphadog-v2-daily-lineups-v0.1.8-today-tomorrow-retention-prune.

Locked:
3. Daily Player Availability / Daily Context Phase 3, latest locked worker alphadog-v2-daily-player-availability-v0.1.3-today-tomorrow-retention-prune.

Locked:
5. Daily Bullpen Availability / Daily Context Phase 5, latest locked worker alphadog-v2-daily-bullpen-availability-v0.1.0-internal-bullpen-history-context.

Next active worker:
7. Daily Umpire Context Worker — PASS / LOCKED
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.

Locked immediately before it:
6. Daily Team Schedule Spot Worker — PASS / LOCKED WITH WARNINGS ACCEPTED.

Remaining future phases:
6. Daily Team Schedule Spot Worker — PASS / LOCKED WITH WARNINGS ACCEPTED.
7. Daily Umpire Context Worker — PASS / LOCKED
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.

Daily Game Status is not a separate remaining worker because Calendar / Delta Certifier already owns Calendar/Game Status.

DO NOT REOPEN:
Do not reopen or patch Daily Lineups unless new SQL/source output proves a real issue. Do not broaden this worker into player availability/weather/bullpen/umpire/team schedule spot. Do not mutate board/prepared/scoring/ranking/final candidate tables. Do not write projected/unposted/partial lineups.

AUTHORITATIVE COMPLETION DOC:
See 72_DAILY_LINEUPS_PHASE_2_COMPLETION.txt.

============================================================

DAILY STARTERS v0.1.3 TODAY+TOMORROW RETENTION UPDATE — 2026-05-28

STATUS SUMMARY:
- Daily Starters / Daily Context Phase 1 remains PASS / LOCKED.
- Latest retention patch: PASS / LOCKED.
- Locked retention batch: daily_starters_batch_mpq1euyv_4fw84r.
- Latest worker: alphadog-v2-daily-probable-pitchers-v0.1.3-today-tomorrow-retention.
- Prior functional lock worker v0.1.2-batched-people-hand-fill is superseded by v0.1.3 for retention behavior.
- Certification: DAILY_STARTERS_CERTIFIED_REFRESHED.
- Grade: PASS.
- window_start = 2026-05-28.
- window_end = 2026-05-29.
- blocking_rows = 0.

ROOT CAUSE:
Daily Starters current-state retention was broader than desired and could keep older dates longer than needed. This was not a source-quality or starter-matching failure; it was a data lifecycle/retention cleanup issue.

FIX:
v0.1.3 changed Daily Starters retention so the worker keeps only PT today + PT tomorrow current data each run. It also prunes legacy/current Daily Starters data outside the active today/tomorrow window. The worker still keeps a small today/tomorrow audit/snapshot trail, but it no longer keeps old dates forever.

VERIFIED RETENTION OUTCOME:
- daily_starters_current retained only:
  - 2026-05-28: 12 rows / 6 games.
  - 2026-05-29: 30 rows / 15 games.
- daily_probable_pitchers retained only:
  - 2026-05-28: 6 rows.
  - 2026-05-29: 15 rows.
- daily_starters_snapshots count after run: 126.
- daily_starters_issues count after run: 32.
- Snapshot/issue count is acceptable under the new model because these are a small today/tomorrow audit trail, not indefinite historical current-state buildup.

PREPARED-BOARD SAFETY OUTCOME:
- prepared_board_relevant = 1 rows remained clean.
- hand_missing_flag = 0 for prepared-board relevant rows.
- actual_started rows = 2.
- probable rows = 6.
- blocking_rows = 0.
- Retention cleanup did not break prepared-board starter coverage.

LOCKED DATA CONTRACT:
- Daily Starters writes daily starter context to DAILY_DB.
- Daily Starters anchors to TEAM_DB.mlb_game_calendar.game_pk.
- Daily Starters reads prepared-board relevance from SCORE_DB.score_board_prepared_current where pickable_safe = 1, matchup_status = 'calendar_matched', player_match_status = 'matched', official_game_pk IS NOT NULL, and official_game_time_utc IS NOT NULL.
- Daily Starters does not mine raw MARKET_DB.prizepicks_board_current or MARKET_DB.sleeper_board_current directly.
- Daily Starters does not mutate raw board tables, prepared board rows, scoring tables, ranking/final candidates, or source/history base/delta tables.

LOCKED STARTER STATUS RULES:
- Do not emit confirmed yet.
- Pregame starters stay starter_status = probable.
- Use actual_started only when live/final source proves it.
- TEAM_DB.starter_history remains historical actual starter data after games are played, not today's probable starter source.

DAILY CONTEXT ROADMAP UPDATE:
- Locked: Daily Starters / Daily Context Phase 1, latest worker alphadog-v2-daily-probable-pitchers-v0.1.3-today-tomorrow-retention.
- Locked: Daily Lineups / Daily Context Phase 2, latest worker alphadog-v2-daily-lineups-v0.1.8-today-tomorrow-retention-prune.
- Locked: Daily Player Availability / Daily Context Phase 3, latest worker alphadog-v2-daily-player-availability-v0.1.3-today-tomorrow-retention-prune.
- Daily Weather / Roof / Park Conditions is locked; Daily Bullpen Availability is locked; Daily Team Schedule Spot is locked; Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior.
- Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior.
- Daily Game Status is not a separate remaining worker because Calendar / Delta Certifier already owns Calendar/Game Status.

AUTHORITATIVE COMPLETION DOC:
See 71_DAILY_STARTERS_PHASE_1_COMPLETION.txt.

============================================================

DAILY STARTERS / DAILY CONTEXT PHASE 1 UPDATE — 2026-05-28

STATUS SUMMARY:
- Daily Starters / Daily Context Phase 1: PASS / LOCKED.
- Locked batch: daily_starters_batch_mpoqi99w_s6n40y.
- Worker: alphadog-v2-daily-probable-pitchers-v0.1.2-batched-people-hand-fill.
- Control Room: alphadog-v2-control-room-v1.6.123-daily-starters-button.
- Orchestrator: alphadog-v2-orchestrator-v0.2.112-daily-starters-dispatch.
- Certification: DAILY_STARTERS_CERTIFIED_REFRESHED.
- Grade: PASS.

ROOT CAUSE / ARCHITECTURE CLARIFICATION:
Daily Game Status / Calendar Status is already owned by TEAM_DB.mlb_game_calendar, TEAM_DB.mlb_game_data_coverage, and the Delta Certifier / calendar-tally system. Daily Starters must not duplicate Calendar/Game Status and must not create a separate Daily Game Status worker for this phase. Daily Starters is a Daily Context layer only.

LOCKED DATA CONTRACT:
- Writes daily starter context to DAILY_DB.
- Anchors to TEAM_DB.mlb_game_calendar.game_pk.
- Reads prepared-board relevance from SCORE_DB.score_board_prepared_current where pickable_safe = 1, matchup_status = 'calendar_matched', player_match_status = 'matched', official_game_pk IS NOT NULL, and official_game_time_utc IS NOT NULL.
- Does not mine raw MARKET_DB.prizepicks_board_current or MARKET_DB.sleeper_board_current directly.
- Does not mutate raw board tables, prepared board rows, scoring tables, ranking/final candidates, or source/history base/delta tables.

FINAL VERIFIED OUTPUT:
- prepared_games_checked = 5.
- prepared_rows_read = 2940.
- calendar/schedule games checked = 51.
- team rows written = 102.
- snapshot rows = 102.
- legacy rows = 51.
- external_calls = 23.
- blocking_rows = 0.
- Prepared-board relevant games: 823626, 824104, 824596, 822897, 823947.
- Prepared-board relevant starter rows = 10.
- All 10 prepared-board starter rows had starter_player_id, starter_name, and starter_hand.
- prepared-board hand_missing_flag = 0.
- latest-batch issues = 0.
- prepared-board relevant issues = 0.
- Gemini official/free MLB source cross-check = PASS.
- prepared-board coverage audit = PASS.

LOCKED SOURCE LOGIC:
- Primary: MLB StatsAPI schedule endpoint with hydrate=probablePitcher(note,person).
- Batched hand fill: /api/v1/people?personIds=...
- Live feed is used only for actual starter validation.
- Do not emit confirmed yet.
- Pregame starters stay starter_status = probable.
- Use actual_started only when live/final source proves it.

AUTHORITATIVE COMPLETION DOC:
See 71_DAILY_STARTERS_PHASE_1_COMPLETION.txt.

============================================================

BOARD PREP / BOARD FULL RUN SCORE PREP INTEGRATION UPDATE — 2026-05-27

STATUS SUMMARY:
- Everyday Board Refresh + Score Board Prep Integration: PASS / LOCKED WITH CAVEATS CORRECTLY BLOCKED.
- Final Board Full Run: board_full_run_mpontjzc_br84v8.
- Chain: chain_board_full_run_mpontjzc.
- Orchestrator: alphadog-v2-orchestrator-v0.2.111-board-full-run-score-prep-required.
- Score Prep worker: alphadog-v2-score-prep-v0.2.5-fast-final-db-truth.
- Final certification: BOARD_FULL_RUN_CERTIFIED_PRIZEPICKS_SLEEPER_AND_SCORE_PREP_PASS.
- Grade: FULL_RUN_PASS.
- Required stages: 3/3: prizepicks-github-board, parlay-sleeper-board, score-prep.
- Critical rule: No Prep = No valid Board Full Run.

CRITICAL SUPERSESSION:
Earlier Board Full Run certifications that only required PrizePicks + Sleeper are historical/outdated. The current standard requires Score Prep. The prepared board in SCORE_DB.score_board_prepared_current is now the downstream contract. Raw board tables in MARKET_DB remain source inventory only.

SAFE DOWNSTREAM CONTRACT:
Future mining/scoring must only consume SCORE_DB.score_board_prepared_current rows where pickable_safe = 1, matchup_status = 'calendar_matched', player_match_status = 'matched', official_game_pk IS NOT NULL, and official_game_time_utc IS NOT NULL. Do not mine raw PrizePicks/Sleeper board tables directly.

BLOCKED ROW POLICY:
Unsafe rows are preserved, flagged, and blocked. Do not mine started/expired rows, source-unpickable rows, player-unresolved rows, calendar-unresolved rows, or combo rows. Remaining combo/missing-player/started/source-unpickable caveats are not current failures.

AUTHORITATIVE COMPLETION DOC:
See 69_BOARD_PREP_AND_BOARD_FULL_RUN_SCORE_PREP_COMPLETION.txt.

============================================================

INCREMENTAL MORNING FULL RUN / 05-26 COVERAGE RECOVERY UPDATE — 2026-05-27

STATUS SUMMARY:
- Incremental Morning Full Run: PASS / LOCKED WITH CAVEAT.
- Final locked run: incremental_morning_full_run_mpns4qom_73qud2.
- Chain: chain_incremental_morning_full_run_mpns4qom.
- Certification: INCREMENTAL_MORNING_FULL_RUN_CERTIFIED_CALENDAR_TALLY_AND_ALL_BASE_DELTAS_PASS.
- Grade: FULL_RUN_PASS.
- Completed stages: 11/11.
- Final calendar/tally blockers: 0.
- Active scheduled time: 5:00 AM Pacific in CONFIG_DB.config_scheduled_jobs, schedule_id incremental_morning_full_run_0500_pt.

CRITICAL SUPERSESSION:
Any earlier Incremental Morning Full Run FULL_RUN_PASS before the 05-26 coverage recovery must be treated as false-pass/outdated unless reconciled with final calendar/tally proof. The current authoritative completion document is 67_INCREMENTAL_FULL_RUN_0526_COVERAGE_RECOVERY_COMPLETION.txt.

FALSE-PASS ROOT CAUSE:
Delta Certifier v0.1.6 allowed scheduled_not_ready / WAITING_NOT_FINAL rows to remain non-blocking even when live source rows had already moved forward. team_game_logs had 05-26 live rows but stale coverage, starter_history had 0 05-26 rows, and bullpen_history had only 12 of 15 games before repair/reconciliation.

CURRENT LOCKED VERSIONS:
- Control Room: alphadog-v2-control-room-v1.6.118-incremental-full-run-calendar-tally-order
- Orchestrator: alphadog-v2-orchestrator-v0.2.107-incremental-full-run-calendar-tally-gates
- Delta Certifier: alphadog-v2-delta-certifier-v0.1.8-bullpen-live-reconcile-after-coverage
- Hitter Game Logs: alphadog-v2-base-hitter-game-logs-v1.6.19-mining-only-no-tally-writes
- Pitcher Game Logs: alphadog-v2-base-pitcher-game-logs-v0.4.6-delta-continuation-before-promotion
- Team Game Logs: alphadog-v2-base-team-game-logs-v0.3.5-calendar-gap-partial-aware-noop-guard
- Starter History: alphadog-v2-base-starter-history-v0.4.7-live-source-gap-scheduled-wait-override
- Bullpen History: alphadog-v2-base-bullpen-history-v0.4.7-calendar-gap-cursor-placeholder-fix
- Hitter Splits: alphadog-v2-base-hitter-splits-v0.4.7-calendar-tally-gap-scoped-refresh
- Pitcher Splits: alphadog-v2-base-pitcher-splits-v0.5.11-calendar-tally-gap-scoped-refresh
- Hitter Metrics: alphadog-v2-base-hitter-metrics-v0.5.1-calendar-tally-gap-scoped-recalc
- Pitcher Metrics: alphadog-v2-base-pitcher-metrics-v0.5.7-calendar-tally-gap-scoped-recalc

FINAL 11-STAGE CHAIN ORDER:
1. delta-certifier precheck
2. base-hitter-game-logs
3. base-pitcher-game-logs
4. base-team-game-logs
5. base-starter-history
6. base-bullpen-history
7. base-hitter-splits
8. base-pitcher-splits
9. base-hitter-metrics
10. base-pitcher-metrics
11. delta-certifier final check

05-26 FINAL COVERAGE:
All 15 games have complete 9-layer coverage. team_game_logs = 30 rows, starter_history = 30 rows, bullpen_history = 85 rows. Coverage/live mismatch detector returned 0 rows. Duplicate checks returned 0 duplicate keys. Historical blocker scan through 2026-05-26 returned 0 rows.

CAVEATS:
- Calendar is_final/is_available_for_stats flags for 05-26 were stale at inspection time, but live-source reconciliation made this non-blocking.
- starter_history min_date is 2026-03-26 while calendar min_date is 2026-03-25; total game count still matches 821 and historical blockers through 05-26 are 0.
- First real scheduled 5:00 AM Pacific fire remains a watch-only item.

RULES FOR FUTURE CHATS:
- Never claim Full Run pass from parent certification alone.
- Require calendar/tally proof, per-game 9-layer coverage, live/coverage parity, duplicate checks, zero blockers, and clean logs.
- PRAGMA/schema-first for any uncertain SQL. Never guess columns/tables.
- Do not reopen locked workers unless new SQL proves a real issue.
- Do not move the Incremental Morning Full Run back to 1:00 AM Pacific.

============================================================

BOARD REFRESH FULL RUN / BOARD SCHEDULER COMPLETION UPDATE — 2026-05-25 / 2026-05-26

STATUS SUMMARY:
- PrizePicks Board: PASS / LOCKED.
- Sleeper Board: PASS / LOCKED.
- Manual Board Refresh Full Run: PASS / LOCKED.
- Scheduled Board Full Run: DEPLOYED / CONFIGURED / READY FOR FIRST REAL SCHEDULED FIRE.
- Static Full Run: unchanged / locked.
- Incremental Morning Full Run: PASS / LOCKED WITH CAVEAT after 05-26 coverage recovery. See 67_INCREMENTAL_FULL_RUN_0526_COVERAGE_RECOVERY_COMPLETION.txt.
- Scoring/ranking/final board: NOT STARTED.
- Daily context: Phase 1 Daily Starters PASS / LOCKED; Phase 2 Daily Lineups PASS / LOCKED; Phase 3 Daily Player Availability PASS / LOCKED; Daily Context Phases 1-7 plus Daily Context Readiness / Enrichment Certifier v0.1.3 are now locked; Daily Context Readiness / Enrichment Certifier v0.1.3 is PASS / LOCKED for started-slate behavior. Daily Team Schedule Spot / Phase 6 is locked at alphadog-v2-daily-schedule-v0.1.6-self-verifying-retention-final.

SCOPE OF THIS PHASE:
This phase covered only the Everyday Board Layer:
1. Retest and sharpen PrizePicks board refresh.
2. Retest and sharpen Sleeper board refresh.
3. Fix board replacement lifecycle.
4. Build manual BOARD > Full Run.
5. Confirm PrizePicks runs first and Sleeper runs second.
6. Add database-driven scheduled Board Full Run at 9:00 AM, 1:00 PM, and 10:00 PM Pacific.
7. Avoid touching Incremental Morning Full Run, Static Full Run, scoring, ranking, final board, daily context, old production, Wrangler, generator, or deploy scripts.

FINAL LOCKED BOARD REFRESH FULL RUN:
- Visible button: BOARD > Full Run.
- Parent job key: board-full-run.
- Worker: alphadog-v2-orchestrator.
- Final chain version: alphadog-v2-orchestrator-v0.2.99-board-full-run-chain.
- Final successful parent request: board_full_run_mplwbw4b_3x9fff.
- Chain: chain_board_full_run_mplwbw4b.
- Status: completed.
- Tick count: 3.
- Certification: BOARD_FULL_RUN_CERTIFIED_PRIZEPICKS_AND_SLEEPER_PASS.
- Certification grade: FULL_RUN_PASS.
- Child order: prizepicks-github-board first, parlay-sleeper-board second.

FINAL PRIZEPICKS BOARD STATUS:
- Worker: alphadog-v2-prizepicks-github-board.
- Final version: alphadog-v2-prizepicks-github-board-v0.1.6-github-sha-fetch-consumer-only.
- Status: PASS / LOCKED.
- Final Board Full Run child request: board_prizepicks_refresh_mplwbwlm_vuh5iu.
- Status: completed.
- Certification: promoted_current_board.
- Rows read: 2474.
- Rows written: 4953.
- Rows promoted/current: 2474.
- Future pickable rows: 2052.
- Expired/started rows: 422.
- External calls: 2.
- Active batch: pp_batch_mplwbyeo_t2xaaz.
- Current rows for active batch: 2474.
- Current distinct batch count: 1.
- Non-active current rows: 0.
- Final verdict: PrizePicks replacement lifecycle is clean; current table contains exactly one active batch.
- Locked architecture: consumer-only; no GitHub Actions dispatch from consumer; no scoring/ranking/final board; no old production mutation.

FINAL SLEEPER BOARD STATUS:
- Worker: alphadog-v2-parlay-sleeper-board.
- Final version: alphadog-v2-parlay-sleeper-board-v0.4.3-single-replacement-board.
- Status: PASS / LOCKED.
- Final Board Full Run child request: board_sleeper_refresh_mplwc6v0_m3z504.
- Status: completed.
- Certification: PARLAY_SLEEPER_BOARD_INVENTORY_PROMOTED_NO_SCORING.
- Rows read: 359.
- Current rows: 359.
- Active batch rows: 1.
- Stage rows: 0.
- Batch rows: 1.
- Source key: parlay_sleeper.
- Current distinct batch count: 1.
- Non-active current rows: 0.
- Pickable rows: 359.
- Slate date: 2026-05-26.
- Batch: sleeper_batch_mplwc8ck_bpmrf8.
- Final verdict: Sleeper replacement lifecycle is clean; old board rows are deleted when a new certified board is promoted; exactly one current active Sleeper board exists.
- Locked architecture: board inventory only; no scoring; RFI/NRFI remains blocked from scoring unless later scoring design explicitly approves it; there must never be two active Sleeper boards.

FINAL DATABASE-DRIVEN SCHEDULER STATUS:
- Final scheduler orchestrator version: alphadog-v2-orchestrator-v0.2.100-db-scheduled-board-full-run.
- Status: DEPLOYED / CONFIGURED / READY FOR LIVE SCHEDULE PROOF.
- Schedule table: CONFIG_DB.config_scheduled_jobs.
- Seeded rows:
  1. board_full_run_0900_pt — local_time 09:00 — timezone America/Los_Angeles — job_key board-full-run — enabled 1.
  2. board_full_run_1300_pt — local_time 13:00 — timezone America/Los_Angeles — job_key board-full-run — enabled 1.
  3. board_full_run_2200_pt — local_time 22:00 — timezone America/Los_Angeles — job_key board-full-run — enabled 1.
- The schedule is database-driven, not hardcoded.
- The orchestrator reads CONFIG_DB.config_scheduled_jobs.
- No Wrangler patch was used.
- No generator patch was used.
- No deploy-script changes were used.
- Wake after deployment confirmed live orchestrator v0.2.100, CONFIG_DB binding present, due_board_full_run_after_pump = 0 because current time was not a scheduled time, no due jobs, no pending/running leftovers, no browser loops, and backend cron path remains controlled.

REMAINING WATCH ITEM:
The first real configured Pacific scheduled fire still needs observation/proof. Expected after the next configured Pacific time:
- A board-full-run parent row with json_extract(input_json,'$.scheduled') = 1.
- schedule_id = board_full_run_0900_pt, board_full_run_1300_pt, or board_full_run_2200_pt.
- scheduled_key = board_full_run_YYYY_MM_DD_HHMM_PT.
- Parent eventually completed.
- PrizePicks child completed first.
- Sleeper child completed second.
- Board current tables freshly replaced.
- No duplicate scheduled_key rows.
- No pending/running leftovers.

FAILURE-AWARE LESSONS FROM THIS PHASE:
1. PrizePicks initially read stale GitHub raw content. Raw branch-cache content is unsafe for active board ingestion. Use GitHub Contents API + blob SHA fetch only.
2. Sleeper initially claimed successful certification while current/active tables were empty. Certification text is not enough; validate current rows and active pointer state.
3. Orchestrator had a partialContinue undefined bug after Sleeper returned successfully. Worker success and queue finalization are separate checks; verify both control_job_runs and control_job_queue.
4. First Board Full Run failed because Sleeper had two active pointer rows. Board refresh means one replacement board globally, not one active board per slate date. New certified board replaces old board.
5. SQL mistakes happened: output_preview is not a real control_job_queue column; it must be a SELECT alias from output_json. D1 can reject large UNION ALL counts; use scalar subqueries for multi-table count checks.

DURABLE RULES GOING FORWARD:
1. Do not touch Incremental Morning Full Run for Board work.
2. Do not touch Static Full Run for Board work.
3. Do not touch scoring/ranking/final board yet.
4. PrizePicks remains consumer-only.
5. Sleeper remains board inventory only.
6. Sleeper RFI/NRFI remains blocked from scoring.
7. There must never be two active Sleeper boards.
8. A new certified board must replace the old board.
9. Manual Board Full Run must remain runnable.
10. Individual board buttons must remain runnable.
11. Scheduler times must remain database-driven.
12. Do not patch Wrangler/generator/deploy scripts unless proven absolutely necessary.
13. Use exact SQL only after confirming columns/tables.
14. Do not give manual Wrangler deploy commands; use the project GitHub ZIP upload workflow.
15. Provide flat ZIPs with only changed files for source patches.
16. Print tests directly on screen.

ARCHIVED PRIOR CONTENT BELOW

INCREMENTAL MORNING FULL RUN READINESS BLOCKER UPDATE — 2026-05-25

Context:
- Chat: 2026-05-25 — Incremental Morning Full Run readiness validation / Hitter Splits + Metrics delta validation.
- This is a partial readiness/blocker documentation update only.
- This is NOT a Full Run completion lock.
- This is NOT a Pitcher Metrics true-delta completion.
- This is NOT a Hitter Metrics true-delta completion.

Current safe state:
- Hitter Splits: PASS / LOCKED FOR DELTA.
- Hitter Metrics: PASS only for retained-stage/live snapshot parity behavior; true upstream affected-player recalculation delta is NOT BUILT.
- Pitcher Metrics: retained-stage/live parity still passes; true upstream affected-player recalculation delta attempt FAILED / NOT RUNNING.
- Full Run: NOT READY. Do not build or schedule Full Run until metric true-delta requirements are resolved or explicitly excluded.

Hitter Splits final verified status:
- Control Room: alphadog-v2-control-room-v1.6.100-hitter-splits-stale-lock-progress-rescue
- Orchestrator: alphadog-v2-orchestrator-v0.2.89-hitter-splits-stale-lock-progress-rescue
- Worker: alphadog-v2-base-hitter-splits-v0.4.6-pitcher-parity-chunk-progress-fix
- Delta completed all affected players.
- Cursor completed: 351 / 351.
- Live rows: 972.
- Duplicate keys: 0.
- Max source snapshot date: 2026-05-24.
- Re-run no-oped cleanly.
- No stuck queue.
- Verdict: Hitter Splits is delta-ready.

Hitter Metrics current status:
- Current DELTA > Hitter Metrics checks STATS_HITTER_DB.hitter_metric_snapshot_stage against STATS_HITTER_DB.hitter_metric_snapshots.
- It repairs missing live snapshot rows from retained snapshot stage.
- It no-ops when live matches retained stage.
- It does not recalculate from fresh hitter_splits.
- It does not recalculate from fresh hitter_game_logs.
- Hitter Metrics current parity delta: PASS.
- Hitter Metrics true upstream incremental recalculation delta: NOT BUILT / FUTURE PHASE.
- Important: After Hitter Splits moved to source_snapshot_date 2026-05-24, Hitter Metrics did not rebuild from the fresher Hitter Splits data. This is not a bug in the current parity design, but it means Hitter Metrics is not true Full Run delta-ready if Full Run requires refreshed metrics after refreshed splits/logs.

Pitcher Metrics current status:
- Pitcher Metrics is NOT DONE for true delta.
- Current retained-stage/live parity behavior still passes.
- Base batch: pitcher_metrics_base_stage_batch_mpk7q6wr_x87epm.
- Base metric input latest game date: 2026-05-21.
- Base metric input split snapshot date: 2026-05-22.
- Granular stage rows: 72072.
- Snapshot rows: 2860.
- Snapshot players: 572.
- Snapshot/live parity: clean.
- Upstream pitcher data has moved fresher after that.

Failed / untrusted Pitcher Metrics true-delta attempt:
- Intended new mode: delta_recalculate_affected_players.
- Expected behavior: fresh pitcher_game_logs / pitcher_splits -> affected players -> recalculated metric stage -> updated snapshot stage -> updated live snapshots.
- Latest run still showed old behavior: mode snapshot_delta_gate, status DELTA_PITCHER_METRICS_SNAPSHOT_NOOP_CURRENT, rows written 0, rows promoted 0.
- No cursor row existed for pitcher_metrics_delta_recalculate_affected_players_cursor.
- No batch existed with mode='delta_recalculate_affected_players'.
- First patch failed deploy with syntax error: Expected ")" but found ":" in alphadog-v2-base-pitcher-metrics.js.
- Follow-up patch showed worker version v0.5.0 but still executed the old snapshot gate.
- Likely remaining contract problems: Control Room did not queue the new recalculation mode; Orchestrator did not preserve/dispatch the new mode; Worker still defaulted to old snapshot_delta_gate; embedded Control Room HTML/button contract was not properly updated; existing DELTA > Pitcher Metrics button was not hard-routed into new behavior.
- Important: Do not trust the last Pitcher Metrics ZIP as final.

Current blocker:
- DELTA > Pitcher Metrics still behaves like the old parity/no-op button.
- It must instead queue and run mode = delta_recalculate_affected_players.
- A valid future fix must prove: affected players detected from fresh pitcher logs/splits; new granular metric rows staged/upserted; snapshot stage rebuilt/replaced for affected players; live snapshots updated; retained stage preserved; cursor exists and completes; no full rebuild unless explicitly necessary and approved; no source table mutation; no scoring/ranking/final board writes.

Full Run status:
- Full Run remains BLOCKED.
- Current safe readiness: Hitter Splits PASS; Hitter Metrics parity PASS; Hitter Metrics true upstream delta MISSING; Pitcher Metrics parity PASS; Pitcher Metrics true upstream delta FAILED / NOT RUNNING; Pitcher Metrics last patch ZIP NOT FINAL / NOT TRUSTED.
- Full Run must remain blocked until one of two decisions is made:
  A. Build true affected-player recalculation delta for Pitcher Metrics and Hitter Metrics.
  B. Explicitly exclude true metric recalculation from Full Run and label metrics as parity-only gates with warning METRICS_TRUE_RECALC_DELTA_NOT_BUILT.
- Do not silently treat parity no-op as true metric refresh.

Next clean engineering action:
- Rebuild Pitcher Metrics true delta correctly from the uploaded current repo/source ZIP.
- Scope must include: Control Room embedded HTML/button contract; Control Room route mode; Orchestrator dispatch mode preservation; Worker mode handling; cursor creation/completion; batch creation with mode='delta_recalculate_affected_players'; affected-player detection from fresh pitcher_game_logs / pitcher_splits; recalculated metric stage rows; refreshed snapshot stage rows; refreshed live snapshot rows.
- Before patching: audit current repo/source ZIP; inspect final v0.4.1 parity worker logic; inspect failed v0.5.0 attempt if present; PRAGMA relevant metric tables; confirm actual current pitcher logs/splits freshness; confirm affected-player detection criteria; define route contract explicitly.
- Do not patch blindly.
- Do not touch deploy scripts.
- Do not touch Wrangler/generator.
- Do not touch Wake.
- Do not touch scoring/ranking/final board.
- Do not create a new worker unless explicitly approved.

ARCHIVED PRIOR CONTENT BELOW

BASE PITCHER METRICS LOCKED — 2026-05-24

Latest completed worker chat:
- 2026-05-24 — Base Pitcher Metrics Worker

Final lock:
- Worker: alphadog-v2-base-pitcher-metrics-v0.4.1-snapshot-retained-stage-parity-repair
- Control Room: alphadog-v2-control-room-v1.6.88-restore-working-html-delta-pitcher-button
- Orchestrator: alphadog-v2-orchestrator-v0.2.76-base-pitcher-metrics-delta-repair-dispatch

Primary new document:
- 61_BASE_PITCHER_METRICS_COMPLETION.txt

Status:
- Base Pitcher Metrics is locked for current snapshot scope.
- It derives from certified STATS_PITCHER_DB.pitcher_game_logs and STATS_PITCHER_DB.pitcher_splits.
- It does not call MLB StatsAPI.
- It does not mutate source tables.
- It does not score, rank, write final board, or mutate market boards.

Verified final live snapshot:
- STATS_PITCHER_DB.pitcher_metric_snapshots
- live rows: 2860
- players: 572
- windows: 5
- promoted rows: 2860
- duplicate live natural keys: 0
- missing live rows from retained stage after repair: 0

Current correct Pitcher Metrics buttons:
- BASE > Pitcher Metrics: used through the completed audit/sample/full-stage/snapshot-prep/snapshot-promote sequence.
- DELTA > Pitcher Metrics: retained-stage/live parity repair or no-op.

Control Room rule reinforced:
- Deployed Control Room serves embedded CONTROL_ROOM_HTML from alphadog-v2-control-room.js.
- control_room.html and the embedded Worker HTML must stay in parity.
- Do not use raw multiline HTML inside a normal quoted JS string.

Boundary:
- True new-data recalculation delta is not built yet.

ARCHIVED PRIOR CONTENT BELOW

BASE HITTER METRICS LOCKED — 2026-05-24

Latest completed worker chat:
- 2026-05-23 / 2026-05-24 — Base Hitter Metrics Worker

Final lock:
- Worker: alphadog-v2-base-hitter-metrics-v0.4.1-snapshot-retained-stage-parity-repair
- Control Room: alphadog-v2-control-room-v1.6.78-layout-parity-clean-buttons
- Orchestrator: alphadog-v2-orchestrator-v0.2.70-hitter-metrics-delta-repair-dispatch

Primary new document:
- 60_BASE_HITTER_METRICS_COMPLETION.txt

Status:
- Base Hitter Metrics is locked for current scope.
- It derives from certified STATS_HITTER_DB.hitter_game_logs and STATS_HITTER_DB.hitter_splits.
- It does not call MLB StatsAPI.
- It does not mutate source tables.
- It does not score, rank, write final board, or mutate market boards.

Verified final live snapshot:
- STATS_HITTER_DB.hitter_metric_snapshots
- live rows: 2450
- players: 490
- windows: 5
- promoted rows: 2450
- duplicate live natural keys: 0
- missing live rows from retained stage: 0

Current correct Hitter Metrics buttons:
- BASE > Hitter Metrics: snapshot prep stage-only; no live promotion.
- DELTA > Hitter Metrics: retained-stage/live parity repair or no-op.

Control Room rule reinforced:
- Deployed Control Room serves embedded CONTROL_ROOM_HTML from alphadog-v2-control-room.js.
- control_room.html and the embedded Worker HTML must stay in parity.

ARCHIVED PRIOR CONTENT BELOW

BASE BULLPEN HISTORY LOCKED — 2026-05-23

Latest completed worker chat:
- 2026-05-22 / 2026-05-23 — Base Bullpen History Worker Stabilization

Final lock:
- Worker: alphadog-v2-base-bullpen-history-v0.4.4-delta-cursor-column-fix
- Control Room: alphadog-v2-control-room-v1.6.63-bullpen-stage-parity-restore
- Orchestrator: alphadog-v2-orchestrator-v0.2.61-base-bullpen-history-delta-ready

Status:
- Base Bullpen History is safe to lock/document.
- Delta is ready for future daily incremental runs.
- No code patches are needed now.

Primary new document:
- 59_BASE_BULLPEN_HISTORY_COMPLETION.txt

Key distinction:
- Base Bullpen History is completed-game historical bullpen appearance rows.
- Daily Bullpen Availability is a later derived volatile/scoring context and was intentionally not built here.

ARCHIVED PRIOR CONTENT BELOW

DOCUMENTATION LIBRARY UPDATE — v19 BASE STARTER HISTORY LOCK

DOCUMENTATION LIBRARY UPDATE — v19 BASE STARTER HISTORY LOCK

DATE: 2026-05-22

This library supersedes the previous version by adding the completed Base Starter History Worker documentation.

Primary new completion document:
- 58_BASE_STARTER_HISTORY_COMPLETION.txt

Final locked artifacts documented:
- Worker: alphadog-v2-base-starter-history-v0.4.4-scoped-repair-order-fix
- Control Room: alphadog-v2-control-room-v1.6.50-base-starter-history-scoped-repair-order-fix
- Orchestrator: alphadog-v2-orchestrator-v0.2.57-base-starter-history-scoped-repair-order-fix

Current project state:
- Base Starter History is READY FOR REAL DAILY INCREMENTAL DELTA.
- Source model is GAME_LOG_STYLE_ACTUAL_START_EVENT_ROWS.
- It aligns with Hitter Game Logs, Pitcher Game Logs, and Team Game Logs.
- It does not use the Splits snapshot architecture.

Verified boundaries:
- No scoring/ranking/final board started.
- No PrizePicks/Sleeper mutation.
- Old production not touched.
- Browser pump not used.

ARCHIVED PRIOR CONTENT BELOW

READ ME UPDATE — v18 TEAM GAME LOGS COMPLETION

This documentation package has been updated to v18 for Base Team Game Logs completion.

Newest authoritative completion doc:
- 57_BASE_TEAM_GAME_LOGS_COMPLETION.txt

Newest status:
- alphadog-v2-base-team-game-logs-v0.3.2-delta-scoped-source-repair is locked.
- Base through 2026-05-18 is complete.
- Dynamic delta through 2026-05-21 is complete.
- No-op, retained-stage restore, and scoped source repair are verified.
- Team Game Logs is ready for real future delta mining with no full re-mining needed.

ARCHIVED PRIOR CONTENT BELOW

READ ME FIRST — LATEST STATE AS OF 2026-05-22

The newest authoritative update is the incremental repair alignment across four worker families. Start with:
- 54_INCREMENTAL_REPAIR_GOLD_STANDARD_COMPLETION.txt
- 55_INCREMENTAL_REPAIR_TEST_MATRIX.txt

This update supersedes the older view that only Base Hitter Splits was current. The current library now records that Base Hitter Game Logs, Base Pitcher Game Logs, Base Hitter Splits, and Base Pitcher Splits have been aligned to the same gold-standard incremental repair model.

ARCHIVED PRIOR CONTENT BELOW

LATEST UPDATE — v16 BASE HITTER SPLITS BASE + DELTA GATE LOCKED THROUGH v0.4.1

Completed chat:
2026-05-21 - Base Hitter Splits Worker

Worker:
alphadog-v2-base-hitter-splits

Current locked versions:
- alphadog-v2-base-hitter-splits-v0.3.1-promotion-partial-resume-fix
- alphadog-v2-base-hitter-splits-v0.4.0-delta-noop-restore-gate
- alphadog-v2-control-room-v1.6.23-delta-hitter-splits-route-enable
- alphadog-v2-orchestrator-v0.2.32-base-hitter-splits-hot-continuation
- alphadog-v2-orchestrator-v0.2.34-delta-hitter-splits-noop-gate

Final lock:
Base Hitter Splits is complete, certified, promoted, and cleaned for current scope. Delta Hitter Splits no-op/restore gate is complete and locked for current scope.

Locked base batch:
- batch_id: hitter_splits_base_stage_batch_mpg0v7bt_r6uszd
- status: COMPLETED_PROMOTED_CLEANED
- certification: BASE_HITTER_SPLITS_BASE_BACKFILL_CERTIFIED_PROMOTED_CLEANED
- grade: BASE_PASS
- source snapshot date: 2026-05-21
- live rows: 950
- stage rows after cleanup: 0
- split rows: vs_left 471 / vs_right 479
- duplicate live keys: 0
- source counters: requests 569, successes 483, TRUE_NO_DATA 86, errors 0

Locked delta/no-op gate:
- latest request: delta_hitter_splits_gate_mpg46tpk_fugx79
- status: DELTA_HITTER_SPLITS_NOOP_CURRENT_SOURCE_SNAPSHOT
- certification: DELTA_HITTER_SPLITS_NOOP_LIVE_SOURCE_SNAPSHOT_CURRENT
- grade: DELTA_NOOP_PASS
- rows_read: 950
- rows_written: 2
- external_calls: 0
- delta cursor: base_hitter_splits_delta_update_cursor
- cursor players_total: 950
- cursor players_processed: 950
- cursor requests_done: 0
- duplicate_count: 0

Source lock:
GET /api/v1/people/{playerId}/stats?stats=statSplits&group=hitting&season=2026&sitCodes=vl%2Cvr

Critical split-source rule:
Hitter splits are season-to-date aggregate snapshot data. Do not apply the 2026-05-18 hitter/pitcher game-log cutoff to hitter splits. Use source_snapshot_date.

Hard boundary:
This update affects hitter splits only. It does not imply pitcher splits, hitter game logs, pitcher game logs, team logs, starter history, bullpen history, scoring, ranking, final board, PrizePicks, Sleeper, or old production changed.

Read this new file for the latest locked hitter splits state:
- 53_BASE_HITTER_SPLITS_COMPLETION.txt

ARCHIVED PRIOR CONTENT BELOW

LATEST UPDATE — v15 PITCHER GAME LOG BASE + DELTA LOCKED THROUGH v0.4.1

LATEST UPDATE — v15 PITCHER GAME LOG BASE + DELTA LOCKED THROUGH v0.4.1

Completed chat:
2026-05-21 - Base Pitcher Game Logs Worker

Worker:
alphadog-v2-base-pitcher-game-logs

Current locked versions:
- alphadog-v2-base-pitcher-game-logs-v0.4.1-hitter-equivalent-scoped-delta
- alphadog-v2-control-room-v1.6.18-pitcher-delta-retained-restore-before-queue
- alphadog-v2-orchestrator-v0.2.29-base-pitcher-scoped-delta-continuation

Final lock:
Pitcher Game Log Base is complete, certified, promoted, and cleaned. Pitcher Game Log Delta is complete, certified, promoted, and stage-retained through 2026-05-20.

Locked base batch:
- batch_id: pitcher_base_backfill_stage_batch_mpf6iuyt_hw56du
- status: COMPLETED_PROMOTED_CLEANED
- certification: BASE_PITCHER_GAME_LOGS_BASE_BACKFILL_CERTIFIED
- grade: BASE_PASS
- base cutoff: 2026-05-18
- rows promoted/live: 5821
- pitcher universe: 740
- player outcomes: 740
- duplicate live keys: 0
- rows after cutoff: 0
- base stage rows after cleanup: 0
- source counters frozen from outcome truth: requests 740, successes 568, no data 172, errors 0

Locked delta batch:
- batch_id: pitcher_delta_update_batch_mpfwl3w1_sc57wz
- mode: delta_update
- status: COMPLETED_PROMOTED_STAGE_RETAINED
- certification: DELTA_PITCHER_GAME_LOGS_CERTIFIED_PROMOTED_STAGE_RETAINED
- grade: DELTA_PASS
- delta start: 2026-05-19
- coverage: 2026-05-19 through 2026-05-20
- scoped affected-pitcher target count: 237, not full 740 universe
- rows staged: 262
- rows promoted/live: 262
- retained stage rows: 262
- cleaned_at: null by design
- duplicate live keys after delta: 0
- latest complete source date verified: 2026-05-20

Verified delta behavior:
- repeated button press no-ops when current
- source freshness check uses MLB schedule final-date discovery
- normal daily delta does not full-sweep the 740-pitcher universe
- scoped affected-pitcher delta used MLB completed-game schedule / boxscore pitching stats, then pitcher gameLog calls for affected pitchers
- stage is retained after promotion and acts as trusted temp copy
- live-only missing row repair restores from retained stage before queue
- retained-stage repair creates no backend queue, no MLB calls, no new batch, no stage writes, no cleanup, and no full sweep

Hard boundary:
This update affects pitcher game-log base/delta documentation only. It does not imply pitcher splits, hitter splits, team logs, starter history, bullpen history, scoring, ranking, final board, PrizePicks, or Sleeper changed.

Read this new file for the latest locked pitcher base/delta state:
- 52_PITCHER_GAME_LOG_BASE_DELTA_COMPLETION.txt

ARCHIVED PRIOR CONTENT BELOW

LATEST UPDATE — v14 HITTER GAME LOG BASE + DELTA LOCKED THROUGH v1.6.12

Completed chat:
2026-05-21 - Hitter Game Log Base + Delta Recovery

Worker:
alphadog-v2-base-hitter-game-logs

Current locked versions:
- alphadog-v2-base-hitter-game-logs-v1.6.12-retained-stage-restore-before-queue
- alphadog-v2-control-room-v1.6.12-retained-stage-restore-before-queue
- Orchestrator remains existing v0.2.23/v0.2.x backend self-continuation path

Final lock:
Hitter Game Log Base is complete, certified, promoted, and cleaned. Hitter Game Log Delta is complete, certified, promoted, and stage-retained through 2026-05-20.

Locked base batch:
- batch_id: hitter_base_backfill_batch_mpelpq0t_akyyu3
- status: COMPLETED_PROMOTED_CLEANED
- certification: BASE_HITTER_GAME_LOGS_BASE_BACKFILL_CERTIFIED
- grade: BASE_PASS
- base cutoff: 2026-05-18
- rows promoted/live: 14717
- player outcomes: 569
- duplicate live keys: 0
- rows after cutoff: 0
- base stage rows after cleanup: 0
- source counters frozen from outcome truth: requests 569, successes 484, no data 85, errors 0

Locked delta batch:
- batch_id: hitter_delta_update_batch_mpetr3nq_160dpk
- run_id: run_delta_hitter_logs_mpetr3nq_7bstvw
- mode: delta_update
- status: COMPLETED_PROMOTED_STAGE_RETAINED
- certification: DELTA_HITTER_GAME_LOGS_CERTIFIED_PROMOTED_STAGE_RETAINED
- grade: DELTA_PASS
- delta start: 2026-05-19
- coverage: 2026-05-19 through 2026-05-20
- rows staged: 650
- rows promoted/live: 650
- retained stage rows: 650
- cleaned_at: null by design
- duplicate live keys after delta: 0
- latest complete source date verified: 2026-05-20

Verified delta behavior:
- repeated button press no-ops when current
- source freshness check uses MLB schedule final-date discovery
- new 2026-05-20 date increment worked without rerunning the 569-player full sweep
- stage is retained after promotion and acts as trusted temp copy
- live-only missing row repair restores from retained stage before queue
- retained-stage repair creates no backend queue, no MLB calls, no new batch, no stage writes, no cleanup, and no full sweep

Hard boundary:
This update affects hitter game-log base/delta documentation only. It does not imply pitcher logs, splits, team logs, starter history, bullpen history, scoring, ranking, final board, PrizePicks, or Sleeper changed.

PACKAGE STATUS: v14 REVIEWED — HITTER GAME LOG BASE + DELTA LOCKED THROUGH v1.6.12

Read these new files for the latest locked hitter base/delta state:
- 50_HITTER_GAME_LOG_BASE_DELTA_COMPLETION.txt
- 51_HITTER_GAME_LOG_BASE_DELTA_HANDOFF_SOURCE.txt

ARCHIVED PRIOR UPDATE — v13 PARLAY SLEEPER BOARD WORKER COMPLETE

LATEST UPDATE — v13 PARLAY SLEEPER BOARD WORKER COMPLETE

Completed chat:
2026-05-20 - Parlay Sleeper Board Worker

Worker:
alphadog-v2-parlay-sleeper-board

Final stable version:
alphadog-v2-parlay-sleeper-board-v0.4.1

Final lock:
First stable Sleeper board ingestion baseline.

Final verified execution path:
1. BOARD > Sleeper
2. ORCHESTRATOR > Wake
3. ORCHESTRATOR > Logs
4. MANUAL SQL > Run

Final verified MARKET_DB lifecycle state:
- sleeper_board_stage: 0
- sleeper_board_batches: 1
- sleeper_board_current: 658 live source rows
- sleeper_board_active_batches: 1

Verified behavior:
- Replacement lifecycle works.
- Batch history no longer accumulates.
- Live count moved from 628 to 658 during repeatability testing; this was normal live-board movement.
- No PrizePicks mutation.
- No scoring.
- No ranking.
- No final board.
- No old production touch.
- No browser pump.

Important RFI/NRFI board-inventory handling:
- Sleeper source field player_first_inning_runs is promoted only as board inventory.
- canonical_prop_key remains rfi_nrfi.
- promotion_status is promoted_board_inventory_only.
- logic_status is blocked_pending_rfi_nrfi_design.
- scoring_enabled remains 0.
- CONFIG_DB.config_prop_taxonomy for rfi_nrfi now supports Reference,Sleeper but remains scoring disabled.
- No RFI/NRFI scoring, ranking, final-board qualification, mining assumption, or recommendation logic was enabled.

ARCHIVED PRIOR UPDATE — v12 STATIC CERTIFIER + FULL RUN COMPLETE

Static Certifier Worker and Static Full Run are complete and verified.
AlphaDog v2 static foundation is fully certified for current scope.

Final Static Certifier:
- Worker: alphadog-v2-static-certifier
- Version: alphadog-v2-static-certifier-v0.1.0-read-only-static-layer-certification
- Certification: STATIC_LAYER_CERTIFIED_ALL_COMPLETED_AND_DEFERRED_STATIC_FOUNDATIONS_PASS
- Read-only validation only
- Rows written: 0
- External calls: 0

Final Static Full Run:
- Certification: STATIC_FULL_RUN_CERTIFIED_ALL_ACTIVE_STATIC_WORKERS_RERAN_AND_FINAL_CERTIFIER_PASSED
- Parent request: static_full_run_mpdo83pr_9put3j
- Chain ID: chain_static_full_mpdo83pr
- Runtime: 7 minutes 4 seconds
- Full run certified: true
- Completed through backend/orchestrator continuation
- No browser pump, no browser auto-loop, no generic dispatch, no old production touch, no scoring, no ranking, no final board, no PrizePicks board mutation.

Verified Full Run order:
1. static-teams
2. static-stadiums
3. static-park-factors
4. static-players
5. static-prop-taxonomy
6. static-certifier

Deferred workers skipped correctly:
- static-rosters
- static-player-aliases

Archived prior note superseded by v13: no next phase is recommended by this documentation update; any future chat must audit current docs and repo/source before coding.

ARCHIVED PRIOR UPDATE — v11 STATIC PROP TAXONOMY COMPLETE

Static Prop Taxonomy Worker is complete and verified.
Worker: alphadog-v2-static-prop-taxonomy.
Final verified version: alphadog-v2-static-prop-taxonomy-v0.1.0-taxonomy-alias-certifier.
Certification: STATIC_PROP_TAXONOMY_21_ROWS_PRIZEPICKS_20_ALIASES_CERTIFIED.
CONFIG_DB.config_prop_taxonomy now has 21 rows.
REF_DB.ref_prop_aliases now has 20 PrizePicks aliases for source_key='prizepicks_github'.
MARKET_DB.prizepicks_board_current had 20 active stat types and 5092 board rows at verification.
Triples is now canonical prop_key triples with scoring disabled.
Pitcher Strikeouts (Combo) is now canonical prop_key pitcher_strikeouts_combo, distinct from pitcher_strikeouts, with scoring disabled.
No PrizePicks board mutation, no scoring, no ranking, no final board write, no Sleeper work, no old production touch, no browser pump.

Important SQL correction locked: do not use cross-database joins in Manual SQL unless the bridge explicitly supports it. Validate MARKET_DB, REF_DB, and CONFIG_DB separately.

Next recommended chat: 2026-05-20 - Static Certifier Worker.
Next recommended worker: alphadog-v2-static-certifier.

READ ME FIRST — ALPHADOG / OXYGEN-COBALT V2 DOCUMENTATION LIBRARY

DATE: 2026-05-20
PACKAGE STATUS: v13 REVIEWED — PARLAY SLEEPER BOARD WORKER COMPLETE

THIS PACKAGE IS THE ACTIVE HANDOFF BRAIN FOR ALPHADOG / OXYGEN-COBALT V2.

Read this file first, then read:
- 02_CURRENT_STATE_MASTER.txt
- 04_LOCKED_DECISIONS_AND_RULES.txt
- 06_NO_GUESSING_VALIDATION_PROTOCOL.txt
- 07_BUILD_HISTORY_FULL.txt
- 08_DATABASE_REGISTRY_FULL.txt
- 09_WORKER_REGISTRY_FULL.txt
- 12_ORCHESTRATOR_DOCUMENTATION.txt
- 18_TESTING_PROTOCOLS.txt
- 19_OPEN_ISSUES_AND_NEXT_STEPS.txt
- 23_LATEST_VERIFIED_OUTPUTS.txt
- 31_STANDARD_REFRESH_LIFECYCLE_LOCK.txt
- 36_STATIC_PLAYERS_WORKER_COMPLETION.txt
- 37_STATIC_ROSTERS_WORKER_CERTIFIED_DEFERRED.txt
- 38_STATIC_PLAYER_ALIASES_WORKER_CERTIFIED_DEFERRED.txt
- 41_NEXT_CHAT_PROMPT_STATIC_DEPTH_CHARTS_WORKER.txt
- 42_STATIC_DEPTH_CHARTS_WORKER_NEXT_PLAN.txt

CURRENT TOP-LEVEL STATE

AlphaDog v2 bootstrap is complete.
Schema phase is complete.
GitHub mobile auto-deploy works.
Control Room v1.5 Wake Now works.
Real Orchestrator backend/cron continuation works.
Wake button skips waiting for cron.
No scoring has started.
No ranking has started.
No final board has started.
Old production must not be touched.
Browser pump/long browser loops must not be used.

COMPLETED / VERIFIED WORKERS

1. Market Source Health Worker
   Worker: alphadog-v2-market-source-health
   Final verified scope: source reachability / identity health only.
   Certification: SOURCE_REACHABLE_WORKER_SCRIPT_PRESENT.

2. PrizePicks GitHub Board Worker
   Worker: alphadog-v2-prizepicks-github-board
   Final verified version: alphadog-v2-prizepicks-github-board-v0.1.3-promote-current-board
   Rows read/staged/promoted: 5092.
   Active pointer table works.

3. Static Team Dictionary Worker
   Worker: alphadog-v2-static-teams
   Final verified version: alphadog-v2-static-teams-v0.1.0-team-dictionary-seed
   REF_DB.ref_teams: 30.
   REF_DB.ref_team_aliases: 177.
   Certification: STATIC_TEAM_DICTIONARY_SEEDED_30_ACTIVE_TEAMS_ALIASES_WRITTEN.

4. Static Stadiums Worker
   Worker: alphadog-v2-static-stadiums
   Final verified version: alphadog-v2-static-stadiums-v0.1.2-chase-field-override
   REF_DB.ref_stadiums: 30.
   REF_DB.ref_stadium_aliases: 270.
   Missing/unknown timezone/roof/surface: 0.

5. Static Park Factors Worker
   Worker: alphadog-v2-static-park-factors
   Final verified version: alphadog-v2-static-park-factors-v0.1.3-temporary-venue-name-fallback
   REF_DB.ref_park_factors active rows: 30.
   Source: Baseball Savant / MLB Statcast Park Factors.
   No fake values.

6. Static Players Worker
   Worker: alphadog-v2-static-players
   Final verified version: alphadog-v2-static-players-v0.1.9-stage-certify-promote-clean
   Certification: STATIC_PLAYERS_STAGE_CERTIFIED_PROMOTED_MAIN_CLEANED
   REF_DB.ref_players active rows: 1310.
   REF_DB.ref_player_aliases rows: 6425.
   REF_DB.ref_rosters active rows: 1310.
   Teams covered: 30.
   Duplicate MLB player IDs: 0.
   Missing MLB player IDs: 0.
   Missing names: 0.
   Stage tables cleaned after promotion.

7. Static Rosters Worker
   Worker: alphadog-v2-static-rosters
   Final status: CERTIFIED / DEFERRED.
   Do not build this worker right now.
   Reason: Static Players v0.1.9 already satisfies the initial static roster foundation through REF_DB.ref_rosters.
   Current repo source audit: alphadog-v2-static-rosters.js is dummy only and performs no real writes/mining.


8. Static Player Aliases Worker
   Worker: alphadog-v2-static-player-aliases
   Final status: CERTIFIED / DEFERRED.
   Do not build this worker right now.
   Reason: Static Players v0.1.9 already satisfies the initial player alias foundation through REF_DB.ref_player_aliases.
   Verified active aliases: 6425.
   Verified active player coverage: 1310 / 1310.
   REF_DB.ref_player_aliases_stage rows: 0.
   Current repo source audit: alphadog-v2-static-player-aliases.js is dummy only and performs no real writes/mining.

STATIC ROSTERS LOCKED DECISION

Static Rosters is certified/deferred.
Do not build alphadog-v2-static-rosters right now because Static Players v0.1.9 already satisfies the initial static roster foundation through REF_DB.ref_rosters.

STATIC PLAYER ALIASES LOCKED DECISION

Static Player Aliases is certified/deferred.
Do not build alphadog-v2-static-player-aliases right now because Static Players v0.1.9 already satisfies the initial player alias foundation through REF_DB.ref_player_aliases.

Locked SQL state:
- REF_DB.ref_players active players: 1310.
- REF_DB.ref_player_aliases total rows: 6426.
- REF_DB.ref_player_aliases active rows: 6425.
- players_with_active_aliases: 1310.
- active_players_without_aliases: 0.
- missing player_id / alias_name / alias_normalized / source_key: 0.
- alias rows without matching active player: 0.
- REF_DB.ref_player_aliases_stage rows: 0.
- only duplicate normalized aliases: max muncy / muncy max for real distinct MLB players 691777 and 571970; explainable and not dangerous.

This worker is not permanently useless. It is deferred until a real alias-specific need appears, such as PrizePicks/Sleeper alias mapping, reviewed alias corrections, or source-specific matching rules.

NEXT RECOMMENDED CHAT

2026-05-20 - Static Depth Charts Worker

NEXT RECOMMENDED WORKER

alphadog-v2-static-depth-charts

FIRST REQUIRED TASK FOR THAT CHAT

Do not build immediately. First audit the current roadmap/source ZIP and confirm whether a depth-chart/reference-layer worker exists or needs to be introduced. If no source file exists yet, define the worker carefully before coding.

Hard boundaries remain:
- no scoring
- no ranking
- no final board
- no PrizePicks mutation
- no Sleeper work
- no opponent backfill
- no old production touch
- no browser pump
- no direct-write main-table refresh rebuilds before certification

MANDATORY REFRESH LIFECYCLE FOR FUTURE STATIC/REFERENCE WORKERS

mine/fetch → stage/temp → certify → promote/replace main → clean staging

============================================================
V24 CRITICAL CURRENT STATUS — 2026-05-25
============================================================

Incremental Morning Full Run Orchestrator is PASS / LOCKED. See 63_INCREMENTAL_MORNING_FULL_RUN_COMPLETION.txt and 64_INCREMENTAL_MORNING_FULL_RUN_SCHEDULING_PLAN.txt before touching Full Run, scheduling, metrics, queue, or orchestrator work.

Locked Full Run baseline:
- Control Room: alphadog-v2-control-room-v1.6.105-incremental-morning-full-run-button
- Orchestrator: alphadog-v2-orchestrator-v0.2.95-full-run-hot-continuation

Scheduling activation observed:
- Orchestrator: alphadog-v2-orchestrator-v0.2.96-scheduled-incremental-morning-full-run

Control Room health recovery observed after /health 1101:
- alphadog-v2-control-room-v1.6.106-health-nowiso-guard

Do not create a new Worker for scheduled Full Run. Do not touch child workers. Do not add boards, markets, scoring, ranking, or final board to this chain.


2026-05-29 UPDATE — DAILY UMPIRE CONTEXT / DAILY CONTEXT PHASE 7 LOCKED
=======================================================================
Daily Umpire Context / Daily Context Phase 7 is PASS / LOCKED.

Locked worker slot:
- alphadog-v2-daily-usage-pulse

Locked worker version:
- alphadog-v2-daily-usage-pulse-v0.2.0-daily-umpire-context-official-source-probe-retention

Control Room:
- alphadog-v2-control-room-v1.6.131-daily-umpire-context-existing-slot-button

Orchestrator:
- alphadog-v2-orchestrator-v0.2.122-daily-umpire-context-existing-slot-dispatch

Request / run / batch:
- request_id: daily_umpire_context_mpq86b3g_rkro23
- run_id: run_mpq86f2k_h7ll49
- batch_id: daily_umpire_batch_mpq86gc0_6u5nip

Certification:
- DAILY_UMPIRE_CERTIFIED_READY
- Grade: PASS

Purpose:
- Game-level umpire assignment sidecar context for today/tomorrow prepared-board-relevant MLB games.
- Anchored to TEAM_DB.mlb_game_calendar and SCORE_DB.score_board_prepared_current prepared-safe rows.
- Uses verified MLB StatsAPI live feed path: live_feed.liveData.boxscore.officials.

Verified plate umpire assignments:
- 824757 — Braves @ Red Sox — Willie Traynor
- 824834 — Blue Jays @ Orioles — Tyler Jones
- 823378 — Cubs @ Pirates — Dan Bellino
- 822896 — Astros @ Rangers — Ramon De Jesus

Verified counts:
- prepared_rows_read: 1909
- prepared_games_checked: 4
- calendar_games_checked: 4
- game_rows_written: 4
- snapshot_rows_written: 4
- issues_written: 0
- assignments_found: 4
- assignments_missing: 0
- assignments_pending: 0
- assignments_changed: 0
- source_failures: 0
- blockers: 0
- warnings: 0
- external_calls: 4
- queue leftovers: 0

Tables owned in DAILY_DB:
- daily_umpire_context_batches
- daily_umpire_context_current
- daily_umpire_context_issues
- daily_umpire_context_snapshots

Retention:
- current/snapshots/issues retain today + tomorrow only.
- batch metadata remains as small audit trail.
- Verified current: 4 total / 4 inside today-tomorrow / 0 outside.
- Verified snapshots: 4 total / 4 inside today-tomorrow / 0 outside.
- Verified issues: 0 total / 0 outside.

Safety boundaries:
- no SCORE_DB mutation
- no board mutation
- no scoring
- no ranking
- no final-board writes
- no calendar rebuild
- no duplicate Daily Game Status / Starters / Lineups / Player Availability / Weather / Bullpen / Team Schedule Spot logic

Caveat:
- Pregame assignment timing is not fully proven. The locked run proved official MLB live feed assignments for near-start/started/finished games. Do not document umpire assignments as always available early pregame.
- Missing/pending/unavailable umpire assignments remain warning-only in v0.2.0 unless future certifier/scoring rules explicitly require blocking.

Daily Context roadmap now:
1. Daily Starters — locked.
2. Daily Lineups — locked.
3. Daily Player Availability — locked.
4. Daily Weather / Roof / Park Conditions — locked.
5. Daily Bullpen Availability — locked.
6. Daily Team Schedule Spot — locked.
7. Daily Umpire Context — locked.
8. Daily Context Readiness / Enrichment Certifier v0.1.3 — PASS / LOCKED for started-slate behavior.

Future chats must not reopen Daily Umpire Context unless new SQL/source output proves a real issue. Future UI changes must update Control Room backend route handling and embedded active HTML / control_room.html parity together.

============================================================
2026-05-31 — MARKET > TEAMS / EXTERNAL GAME-TEAM ODDS LOCK
============================================================
Update date: 2026-05-31

Market > Teams / External Game-Team Odds Context Miner is now PASS / LOCKED WITH SOURCE-COVERAGE CAVEATS ACCEPTED.

Worker: alphadog-v2-market-normalizer
Locked version: alphadog-v2-market-normalizer-v0.1.7-batched-teams-evidence-finalization
Latest verified request: market_teams_mpthxqh8_bcykzr
Latest verified run: run_mpthy29v_irfgvg
Latest verified batch: market_context_probe_batch_mpthy2df_ubup40
Certification: MARKET_TEAMS_GAME_ODDS_EVIDENCE_WRITTEN
Grade: PASS
Runtime: 38,044 ms
External calls: 46

This worker owns the external game/match/team-level Odds API lane only. It does not mine player props, hitter props, pitcher props, PrizePicks, Sleeper/Parlay, scoring, ranking, matrix, final board, Score Prep, prepared board mutation, or market_current_lines writes.

Control Room lane/name is Market > Teams. Old "Context Probe" wording is deprecated for this worker/lane.

External mining group sequence:
1. Teams — done / locked; external game/match/team-level odds markets.
2. Props — done / locked; external player prop line context for hitter and pitcher props together.

Superseded: separate external Hitters and Pitchers workers are no longer future requirements for external market mining.

Covered cleanly: h2h/moneyline, spreads/run line, totals/game total, alternate spreads, alternate totals, book coverage, market freshness, consensus/best prices, and derived implied runs. Direct team totals are partially covered only when source returns them: latest run had DraftKings-only team totals for 12 of 15 games. Movement/openers are not currently covered and require snapshot/history design.

Latest validation: 15/15 events mapped high confidence, 15/15 game summaries PARSED_OK, bad_summary_rows = 0, market_context_probe_game_odds = 2,750 rows, market_context_probe_game_market_summary = 15 rows, market_context_probe_book_market_status = 630 rows, player prop rows = 0, market_current_lines rows = 0, no active/stuck market-normalizer jobs.

Historical note: v0.1.6 had a stuck/finalization issue after writing evidence. v0.1.7 fixed batched Teams evidence finalization. Do not reopen v0.1.6 unless historical debugging is explicitly requested.

Dedicated completion document: 81_MARKET_TEAMS_EXTERNAL_GAME_ODDS_COMPLETION.txt


============================================================
UPDATE 037 — MARKET > PROPS / EXTERNAL PLAYER PROP LINE MARKET CONTEXT LOCK
============================================================
Update date: 2026-06-01

Market > Props / External Player Prop Line Market Context Miner is now PASS / LOCKED.

Actual final architecture correction:
- External market mining is split as Teams + Props, not Teams + separate external Hitters + separate external Pitchers.
- Market > Teams owns external game/match/team odds context only.
- Market > Props owns external player prop line context for both hitter props and pitcher props.
- Old planned separate external hitter and external pitcher workers are superseded by the single Props lane/worker.

Worker: alphadog-v2-market-line-shape-classifier
Locked source version: alphadog-v2-market-line-shape-classifier-v0.2.10-bovada-total-strikeouts-title-parser
Control Room latest version observed: alphadog-v2-control-room-v1.6.148-market-pitcher-prop-button
Latest locked pitcher request: market_pitchers_mpuwscpx_8gybss
Latest locked pitcher run: run_mpuwsmxv_5oe5nb
Latest locked pitcher batch: market_pitcher_props_batch_mpuwsn0q_sd9c0w
Latest locked hitter batch from same worker line: market_hitter_props_batch_mpuuvmlu_5br6r2
Certification: MARKET_PLAYER_PROP_CONTEXT_EVIDENCE_WRITTEN
Certification grade: PASS_WITH_WARNINGS

Scope locked:
- external player prop line market context
- hitter prop lines where source supports them
- pitcher prop lines where source supports them
- source event/game mapping
- source player/MLBAM/ref-player mapping
- source prop key to canonical AlphaDog prop key mapping
- line value, side, and American price extraction where available
- prepared-board row anchoring where possible
- external-valid but not prepared-board bucket
- quarantine buckets for template/bad-source rows
- evidence/probe writes only

Explicit non-scope:
- no scoring
- no ranking
- no matrix building
- no final board
- no internal hitter factor mining
- no internal pitcher factor mining
- no game/team odds mining; Market > Teams owns that
- no mutation of prepared board or raw board source tables

Latest pitcher validation: rows_read 148, rows_written 1091, external_calls_performed 9, prepared_rows_read 148, prepared_games_checked 10, prepared_players_checked 19, prepared_prop_keys_checked 5, parlay_inventory_rows_seen 612, parlay_props_mapped_to_prepared 208, total_non_owned_units 58, total_non_owned_pct 100, external_valid_unanchored_rows 224, quarantined_rows 40, true_hard_unmatched_rows 0.

Latest hitter validation: rows_read 3547, rows_written 6808, external_calls_performed 11, prepared_rows_read 3547, prepared_games_checked 9, prepared_players_checked 178, prepared_prop_keys_checked 11, parlay_inventory_rows_seen 2089, parlay_props_mapped_to_prepared 1248, total_non_owned_units 733, total_non_owned_pct 43.8, external_valid_unanchored_rows 346, quarantined_rows 151, true_hard_unmatched_rows 4, true_hard_unmatched_rate_excluding_quarantined 0.3, coverage_plus_external_valid_pct_excluding_quarantined 99.7.

Verified source lane from lock outputs: Parlay API player prop evidence was used for the completed Props worker. Odds API hitter prop worker was separately observed as oddsapi-reference, but this Props lock is for alphadog-v2-market-line-shape-classifier / Parlay API player prop context. Gemini API is not source-of-truth and was not part of this lock.

Verified MARKET_DB evidence table from SQL: market_context_probe_player_props. Exact retained table list beyond that was not fully provided in the lock note; do not invent additional table names without PRAGMA/sqlite_master verification.

Historical attempts documented: hitter parsing matured through v0.2.1-v0.2.7; pitcher mode matured through v0.2.8-v0.2.10. Final locked worker version is v0.2.10. v0.2.10 fixed Bovada title-style pitcher parsing, including Total Strikeouts - Joe Ryan (MIN). Final pitcher hard unmatched rows = 0.

External mining state after this update:
1. Market > Teams — PASS / LOCKED.
2. Market > Props — PASS / LOCKED.
External market mining is complete for the current pre-scoring design unless future explicit expansion is approved.

Next worker group is internal only:
1. Hitter Prop Factor Miner — internal-derived factors only.
2. Pitcher Prop Factor Miner — internal-derived factors only.
3. Prop Factor Matrix Builder — internal composer, no scoring yet.
4. Scoring Engine — later, after matrix certification.
5. Ranking / Final Candidate Board — later.
6. Results / Calibration — later.

Dedicated completion document: 82_MARKET_PROPS_EXTERNAL_PLAYER_PROP_LINES_COMPLETION.txt

============================================================
PROP FACTOR MATRIX BUILDER / MATRIX CERTIFIER LOCK UPDATE — 2026-06-02
============================================================

Status: PASS / LOCKED.

Logical worker: alphadog-v2-prop-matrix-builder.
Deployed/reused worker slot: alphadog-v2-phase2b-certifier.
Job key: prop-matrix-builder.
Control Room button: MATRIX > Build.
Control Room version after fix: alphadog-v2-control-room-v1.6.151-matrix-build-allowlist-fix.
Patch ZIP delivered: alphadog_matrix_builder_patch_v0_1_1_allowlist_fix.zip.
Changed files: alphadog-v2-control-room.js, control_room.html, alphadog-v2-orchestrator.js, alphadog-v2-phase2b-certifier.js.
Deployment: existing iPhone/GitHub auto-deploy flow; no Wrangler deployment was used or recommended.

Purpose: internal-only Matrix Assembly / Matrix Certification. This worker consumes current safe prepared rows, hitter/pitcher factor packets and coverage, market context, daily context readiness, and issue/warning ledgers to produce one matrix current row per safe prepared row in SCORE_DB.

Output tables in SCORE_DB:
- prop_matrix_batches
- prop_matrix_current
- prop_matrix_issues
- prop_matrix_coverage_current

Final verified run:
- status: completed_with_certified_matrix_rows
- certification_status: PROP_MATRIX_CERTIFIED_ONE_ROW_PER_SAFE_PREPARED_ROW
- certification_grade: PASS_WITH_BLOCKED_OR_DEFERRED_ROWS
- prepared_rows_read: 585
- matrix_rows_written: 585
- distinct prepared rows: 585
- duplicate matrix rows: 0
- missing safe prepared rows: 0
- matrix_partial_context rows: 508, blocking_for_scoring = 0
- matrix_blocked rows: 54, blocking_for_scoring = 1, reason DAILY_CONTEXT_READINESS_HARD_BLOCKER
- matrix_deferred rows: 23, blocking_for_scoring = 1, reason PROP_DEFERRED_PENDING_SEPARATE_DESIGN
- issue_rows: 1,838
- warning_rows: 585
- blocker_rows: 77
- missing_component_rows: 0
- created_at: 2026-06-02 07:30:27
- updated_at: 2026-06-02 07:30:32

Retention verified:
- prop_matrix_current: only 2026-06-02, 585 rows.
- prop_matrix_coverage_current: only 2026-06-02, 585 rows.
- prop_matrix_issues: only 2026-06-02, 1,838 rows.
- prop_matrix_batches: window_start 2026-06-02, window_end 2026-06-03, 1 row.
Matrix data is volatile and uses today/tomorrow retention; it should not accumulate forever.

Root-cause/freshness history: before matrix run, Market + Hitter Factor prerequisites were stale against current prepared board batch score_board_prep_batch_mpw67is9_aazzfc. Refreshing MARKET > Teams, MARKET > Hitters, MARKET > Pitchers, PROP FACTOR > Hitters, and PROP FACTOR > Pitchers aligned prerequisites. Missing hitter factor coverage dropped to 0 for all prop groups.

Initial button failure: MATRIX > Build returned unknown_or_not_enabled_v2_control_room_job because orchestrator_enqueue_prop_matrix_builder was missing from the Control Room runJob allowlist. Fixed in v1.6.151-matrix-build-allowlist-fix. This was an allowlist/UI-route issue, not matrix logic.

Strict non-goals: no scoring, no ranking, no final candidate board, no result tracking, no calibration, no RFI/NRFI design, no external API calls, no Odds API, no Parlay API, no Gemini API, no MLB API, no final-board writes.

Accepted caveats: 508 non-blocking rows are classified as matrix_partial_context rather than matrix_ready/matrix_ready_with_warnings due to daily/market warnings; this is conservative and not a bug. 54 Daily Context hard blockers are real blockers carried forward. 23 RFI/NRFI rows remain deferred for separate future design.

Next phase: Ranking / Final Candidate Board. Results/calibration and RFI/NRFI separate design remain future phases. Scoring Engine documentation update 040 records architecture/rules but exact final lock values were not supplied in this chat.

See 84_PROP_FACTOR_MATRIX_BUILDER_COMPLETION.txt for full lock details.


============================================================
SCORING ENGINE DOCUMENTATION UPDATE 040 — SOURCE-TRUTH LIMITED
============================================================

Dedicated doc:
85_SCORING_ENGINE_COMPLETION.txt

Phase:
Scoring Engine / AlphaDog Score + High-Score Archive Snapshot Layer.

Source-truth note:
The update request referenced a final Scoring Engine lock report, but the actual final lock report body was not present in the supplied message or latest uploaded documentation ZIP. Per the no-guessing rule, exact values not present in source are recorded as "not provided in final lock note" instead of invented.

Documented phase rules:
- Scoring Engine consumes certified matrix rows and produces scored prop-leg rows.
- It creates permanent high-score archive snapshots for score_0_100 >= 70.
- score_0_100 >= 70 is an archive/preservation threshold, not necessarily final-board qualification.
- Score is an AlphaDog modeled score/confidence score unless Results / Calibration later proves calibration.
- Scoring Engine is side-aware: regular/two-sided lines may evaluate More and Less; Goblin/Demon are More-only.
- Goblin/Demon Under/Less must be blocked/deferred, not promoted or archived as playable.
- Scoring Engine is variation-aware: prepared_row_id/source_line_id/game/player/prop/line/source/odds type must remain distinct.
- Deduplication and display suppression belong to Ranking / Final Candidate Board, not Scoring Engine.
- Scoring Engine does not mine, refresh upstream layers, rank, write final board, grade results, calibrate, or mutate upstream tables.

Next phase:
Ranking / Final Candidate Board.

Future phase:
Results / Calibration Tracker.

Open source-truth gap:
Exact Scoring Engine worker versions, request_id, batch_id, certification, row counts, archive counts, changed files, and output table names were not provided in the final lock note available to this documentation update.

============================================================
SCORING ENGINE REDO UPDATE 041 — VERIFIED SQL EVIDENCE
============================================================
Using 041.zip as the base documentation library, Scoring Engine documentation was redone with exact pasted Manual SQL evidence.

Latest verified Scoring Engine batch:
- simulation_batch_id: scoring_simulation_batch_mq1dboay_iq7h6r
- worker_version: alphadog-v2-scoring-engine-v0.3.7-live-playable-market-context-gate
- status: completed_simulation_shadow_only
- certification: SCORING_SIMULATION_V0_3_7_LIVE_PLAYABLE_MARKET_CONTEXT_GATE_PASS_WITH_REVIEW_WARNINGS
- certification_grade: PASS_WITH_REVIEW_WARNINGS
- matrix_rows_read: 5353
- simulation_rows_written: 10706
- strict_b_rows_written: 5353
- hybrid_control_rows_written: 5353
- started_at: 2026-06-05 20:19:56
- finished_at: 2026-06-05 20:22:21

Verified scoring tables from pasted SQL:
- SCORE_DB.scoring_engine_simulation_batches
- SCORE_DB.scoring_engine_simulation_shadow

Documented caveats:
- Exact final PASS / LOCKED vs PASS / LOCKABLE wording was not supplied in a standalone final lock report.
- Score_0_100 is documented as AlphaDog modeled score/confidence, not historically calibrated hit probability.
- High-score archive threshold score_0_100 >= 70 is evidence preservation, not final-board qualification.
- Exact permanent archive physical table names/counts were not proved in the pasted evidence.
- Ranking / Final Candidate Board remains separate from Scoring Engine in this handoff.
- Results / Calibration Tracker remains later.
- Goblin/Demon variants remain More-only; Under/Less must be blocked/deferred.
- Variations must be scored independently; dedupe/display belongs downstream.

See:
- 00_DOCUMENTATION_UPDATE_041_SCORING_ENGINE_REDO_FROM_041.txt
- 85_SCORING_ENGINE_COMPLETION.txt




============================================================
DOCUMENTATION UPDATE 043 — 2026-06-09 DAILY FULL RUN / SCHEDULED DAILY FULL RUN / SCORING STATE RECONCILIATION
============================================================

This file was updated/reconciled by Documentation Update 043. See:
- 00_DOCUMENTATION_UPDATE_043_EVERYDAY_FULL_RUN_AND_SCORING_STATE.txt
- 86_DAILY_FULL_RUN_AND_SCHEDULED_RUN_STATUS.txt
- 87_SCORING_SYSTEM_CURRENT_STATE_AND_NEXT_PHASES.txt
- 88_CALENDAR_TALLY_SCHEDULED_STUCK_RECOVERY_HANDOFF.txt
- 98_DOCUMENTATION_REVIEW_MANIFEST_v44.txt

Key verified additions:
- Daily Full Run request daily_full_run_mq68o26h_hwtuc2 completed end-to-end with certification DAILY_FULL_RUN_CERTIFIED_WITH_WARNINGS and grade FULL_RUN_PASS_WITH_WARNINGS.
- Daily Context Full Run completed 8/8 with accepted context warnings.
- Board Full Run completed 3/3 with PrizePicks, Sleeper, and Score Prep pass.
- Market/Scoring Full Run completed 9/9 with certification MARKET_SCORING_FULL_RUN_CERTIFIED_CHAIN_COMPLETED.
- PrizePicks recovered and healthy: 5871 current rows, 5871 distinct projection_ids, one current batch, 5871 pickable rows, source health healthy.
- Sleeper current rows: 993, one current batch.
- Prepared current rows: 6854; pickable_safe rows: 6841; PrizePicks rows: 5861; Sleeper rows: 993; blocked rows: 13; calendar matched rows: 6854; player matched rows: 6841.
- Scoring Engine current rows: 6841; score range 55-93; average score 75.01051709027169; worker version alphadog-v2-scoring-engine-v0.4.18-hit-probability-fast-hp-board-terminal.
- Score Final Board current rows: 898; one final board batch; score range 76-93; average score 78.47104677060133; worker version alphadog-v2-score-final-board-v0.1.24-no-archive-and-preserve-engine-elite.
- Hit Probability Board current rows: 795; HP range 10-90; average HP 40.83182389937107; certification HP_BOARD_DISPLAY_CALIBRATION_CERTIFIED_INTERNAL_RECENT_FORM; grade PASS_WITH_TRUE_CALIBRATION_BLOCKED. This is internal recent-form/display HP, not proven true historical calibration.
- CONFIG_DB schedule rows are configured for daily-full-run at 09:00 PT and 13:00 PT, both enabled, timezone America/Los_Angeles, dedupe_scope pacific_date_and_local_time. Existing incremental_morning_full_run_0500_pt remains enabled. Old board-full-run schedules remain disabled.
- Orchestrator patch alphadog_orchestrator_v0216_scheduled_daily_full_run.zip was delivered to make daily-full-run schedule scanning behave like the morning delta full run. Automatic scheduled firing is not proven until v0.2.216 or later is deployed and a scheduled row fires.

Warnings/caveats preserved:
- The failed daily_weather_roof_mq68omwm_v5rzdq queue row is an intentional stale-child replacement audit row. The replacement daily_weather_roof_mq68wrs9_1fnox5 completed successfully.
- Calendar/Tally / Incremental Morning Full Run scheduled-stuck recovery remains an open continuation item.
- RFI/NRFI remains deferred pending separate design.
- Results / Calibration Tracker is not built/proven.
- True historical hit-probability calibration is not proven.
- Physical high-score archive tables/counts are not asserted unless separately proven by schema/output.


============================================================
UPDATE 045 QUICK READ — 2026-06-12
============================================================
A new documentation update has been added: 00_DOCUMENTATION_UPDATE_045_FULL_RUN_MAIN_UI_SCHEDULE_HP_SANITY_STATE.txt. It records the latest full-run/main-system-health state, June 12 calendar/tally proof, Main UI viewer direction, hitter HP raw-gap calibration findings, pitcher HP/scoring flatness findings, and the new open phase for a definitive sanity comparison board. No code changes were made by this documentation update.

================================================================================
DOCUMENTATION UPDATE 046 — FULL RUN / RESCORING / DELTA GAP / BASELINE STATUS
================================================================================
See: 00_DOCUMENTATION_UPDATE_046_FULL_RUN_RESCORING_DELTA_BASELINE_STATUS.txt
See also: 91_INCREMENTAL_MORNING_FULL_RUN_2026_06_14_DELTA_GAP_ROOT_CAUSE.txt; 92_PLAYER_BASELINE_SANITY_HP_COMPLETION_2026_06_14.txt; 93_SCORE_ENRICHMENT_PATCH_HISTORY_AND_OPEN_VALIDATION.txt; 98_DOCUMENTATION_REVIEW_MANIFEST_v45.txt

Key carried state:
- Market/Scoring Full Run baseline remains locked and not superseded by this chat.
- Incremental Morning Full Run 2026-06-14 05:00 PT failed correctly because final Calendar/Tally found 2026-06-13 blockers.
- Root evidence: STATS_HITTER_DB.hitter_game_logs contains 0 rows for 2026-06-13; final calendar marks all 15 06/13 games Final/stats-available.
- Blockers were not postponed/cancelled game handling and not a single game.
- Player Baseline Sanity completed PASS in batch player_baseline_sanity_batch_mqdb6irf_0zxbkb with 9,884 rows promoted.
- Player Baseline HP completed PASS in batch player_baseline_hp_batch_mqdd5rvz_outqo7 with 84,686 rows promoted.
- No code was patched by this documentation update.
- No patch was approved for the 2026-06-13 Morning Delta gap root. Debug target remains hitter delta cursor/window and starter_history target selection.



================================================================================
UPDATE 051 — 2026-06-29 DEEP FULL-RUN / SCORING / BASELINE / BOARD STATE
================================================================================

See dedicated deep update document:
- 00_DOCUMENTATION_UPDATE_051_DEEP_FULL_RUN_SCORING_BASELINE_BOARD_MARKET_STATE.txt

Current top-level proven state from latest pasted SQL/Control Room outputs:
- Latest Daily Full Run chain daily_full_run_mqzhwv1w_6nhvol failed at Market/Scoring.
- Market/Scoring request market_scoring_full_run_mqzixjk5_38821a failed at Market Teams.
- Market Teams request market_context_teams_mqzixrxx_gcdgiw failed with market_normalizer_service_binding_timeout_after_75000ms.
- MARKET_DB nevertheless contains DB evidence for the failed Market Teams request: batch market_context_probe_batch_mqzixzgb_qziivr, prepared_rows_read 8778, prepared_games_checked 13, odds_api_events_seen 14, odds_api_events_mapped 13, odds_api_game_odds_rows 1304, 13 game_market_summary rows, 14 event_map rows.
- Grounded root: Market Teams wrote DB evidence but did not terminalize before service-binding timeout; parent failed because DB-truth recovery/terminalization was not yet proven active for Market Teams.
- Daily Context completed with warnings in the latest chain; Board Full Run completed before the Market Teams failure in the latest chain.
- Expansion delta baseline completed earlier on 2026-06-29 with request expansion_baseline_full_run_mqz85hp1_soee3p and certification EXPANSION_DELTA_FULL_RUN_CERTIFIED_NEW_BASELINE_READY, but it was baseline-only/expansion-only and explicitly no scoring/final-board mutation.
- V3 scoring/final board remains shadow/review only. Do not claim live plays.
- HP percentages are model-estimated shadow HP only; true calibration is NOT PROVEN in this chat.
- Do not query nonexistent MARKET_DB tables market_game_odds_current or market_game_odds_batches; use market_context_probe_* tables proven by PRAGMA.

No code changes are made by this documentation update.
